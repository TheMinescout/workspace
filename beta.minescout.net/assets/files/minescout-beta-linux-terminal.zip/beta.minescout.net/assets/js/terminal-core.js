/* MINESCOUT TERMINAL CORE V6.0 — LINUX WORKSTATION EDITION
    - Linux shell / workstation visual language
    - Ambient particle field
    - All existing site, vault, game, auth and navigation logic preserved
*/

(function() {
    console.log("Initializing Minescout Terminal Core v6.0 (Linux Workstation Edition)...");

    const ADMIN_EMAIL = "theminescout@minescout.net";
    const APPROVED_ADMINS = [ "theminescout@minescout.net" ];

    // --- DATA VAULT (now: "Context Memory") ---
    const VAULT_API = "https://life.minescout.net/api/vault";
    const VAULT_MAX_LEVEL = 9;
    const VAULT_MAX_ATTEMPTS = 4;

    const VAULT_STATE = {
        active: false,
        sessionId: null,
        stake: 0,
        attempts: VAULT_MAX_ATTEMPTS,
        words: [],
        level: 0,
        highestLevel: 0,
        unlockedFiles: []
    };

    const VAULT_FILES = [
        ["README.txt", 0],
        ["vault_status.dat", 0],
        ["access_L1.txt", 1],
        ["access_L2.txt", 2],
        ["access_L3.txt", 3],
        ["access_L4.txt", 4],
        ["access_L5.txt", 5],
        ["access_L6.enc", 6],
        ["access_L7.enc", 7],
        ["access_L8.enc", 8],
        ["root_fragment.dat", 9]
    ];

    const CONFIG = {
        level: 0,
        aliases: JSON.parse(localStorage.getItem('ms_aliases')) || {},
        history: []
    };

    // --- API HELPERS ---
    async function vaultRequest(path, options = {}) {
        const username = window.currentUser?.username;
        if (!username) throw new Error("Authentication required. Please log in to use Context Memory.");

        const requestOptions = { ...options };
        let body = {};
        if (requestOptions.body) {
            try { body = JSON.parse(requestOptions.body); } catch (_) { body = {}; }
        }
        body.username = username;
        requestOptions.body = JSON.stringify(body);

        const response = await fetch(`${VAULT_API}${path}`, {
            credentials: "include",
            ...requestOptions,
            headers: { "Content-Type": "application/json", ...(requestOptions.headers || {}) }
        });

        let data = {};
        try { data = await response.json(); } catch (_) {}
        if (!response.ok) throw new Error(data.error || data.message || `API error HTTP ${response.status}`);
        return data;
    }

    // --- AI CHAT ---
    async function askAI(question) {
        print(`> Sending to Minescout AI: "${question}"`, "log-warn");
        const loadingId = "ai_" + Date.now();
        print(`<div id="${loadingId}" class="holo-loading">❯ Awaiting response…  ▋</div>`);

        const workerUrl = `https://thomas-chat.tmcarleton11.workers.dev/ask`;
        try {
            const response = await fetch(workerUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: question, username: window.currentUser?.username || "guest" })
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            let answerText = "";
            const ct = response.headers.get("content-type");
            if (ct && ct.includes("application/json")) {
                const d = await response.json();
                answerText = d.answer || d.response || d.text || JSON.stringify(d);
            } else {
                answerText = await response.text();
            }

            const el = document.getElementById(loadingId);
            if (el) el.remove();
            print(`> Minescout AI:\n${answerText.trim()}`, "log-secret");
        } catch (error) {
            const el = document.getElementById(loadingId);
            if (el) el.remove();
            print(`> Connection error: ${error.message}`, "log-err");
        }
    }

    // --- VAULT STATE ---
    function vaultSetState(data) {
        VAULT_STATE.level = Math.max(0, Math.min(VAULT_MAX_LEVEL, Number(data.level) || 0));
        VAULT_STATE.highestLevel = Math.max(VAULT_STATE.level, Math.min(VAULT_MAX_LEVEL, Number(data.highestLevel) || 0));
        VAULT_STATE.unlockedFiles = Array.isArray(data.unlockedFiles) ? data.unlockedFiles : [];
        if (VAULT_STATE.level < 10) CONFIG.level = VAULT_STATE.level;

        const titleBar = document.querySelector(".cmd-title-bar span");
        if (titleBar && !(window.currentUser && APPROVED_ADMINS.includes(window.currentUser.username.toLowerCase()))) {
            titleBar.innerText = `context [depth: ${VAULT_STATE.level}]`;
        }
    }

    async function vaultLoadState(silent = false) {
        try {
            const data = await vaultRequest("", { method: "GET" });
            vaultSetState(data);
            return data;
        } catch (error) {
            if (!silent) print(`> ${error.message}`, "log-err");
            return null;
        }
    }

    function vaultHexNoise(length) {
        const chars = "0123456789ABCDEFabcdef·∷⟩⟨";
        let out = "";
        for (let i = 0; i < length; i++) out += chars[Math.floor(Math.random() * chars.length)];
        return out;
    }

    function vaultRenderPuzzle(message = "") {
        let output =
`CONTEXT MEMORY PROBE v5.0
═══════════════════════════════
Identify the token to expand context window

Current depth : L${VAULT_STATE.level}
Stake value   : ${VAULT_STATE.stake}
Attempts left : ${"▪ ".repeat(VAULT_STATE.attempts)}

`;
        if (message) output += `${message}\n\n`;

        VAULT_STATE.words.forEach((word, index) => {
            const address = `0x${(4000 + index * 24).toString(16).toUpperCase()}`;
            output += `${address}  ${vaultHexNoise(6)} ${word} ${vaultHexNoise(6)}\n`;
        });

        output += `\nType '$ probe select [TOKEN]' to attempt.\nType '$ probe abort' to exit.`;
        print(output);
    }

    async function vaultStart(stake) {
        await vaultLoadState(true);
        if (!window.currentUser) { print("> Authentication required to use Context Memory.", "log-err"); return true; }
        if (VAULT_STATE.level >= VAULT_MAX_LEVEL) {
            print(`> Maximum context depth reached (L${VAULT_STATE.level}).\n> L10 access is granted by admin only.`, "log-warn");
            return true;
        }
        if (VAULT_STATE.level === 0 && stake !== 0) {
            print("> L0 training requires no stake.\n> Usage:\n  $ probe\n  $ probe confirm", "log-err");
            return true;
        }
        if (VAULT_STATE.level > 0 && (!Number.isInteger(stake) || stake < 1 || stake > VAULT_STATE.level)) {
            print(`> Invalid stake.\n> Current depth: L${VAULT_STATE.level}\n> Valid range: 1–${VAULT_STATE.level}`, "log-err");
            return true;
        }
        try {
            const data = await vaultRequest("/hack/start", { method: "POST", body: JSON.stringify({ stake }) });
            VAULT_STATE.active = true;
            VAULT_STATE.sessionId = data.sessionId;
            VAULT_STATE.stake = stake;
            VAULT_STATE.attempts = Number(data.attempts || VAULT_MAX_ATTEMPTS);
            VAULT_STATE.words = Array.isArray(data.words) ? data.words.map(w => String(w).toUpperCase()) : [];
            vaultRenderPuzzle(data.message || "");
        } catch (error) {
            print(`> Probe initialization failed:\n  ${error.message}`, "log-err");
        }
        return true;
    }

    async function vaultGuess(word) {
        word = String(word || "").trim().toUpperCase();
        if (!VAULT_STATE.active) { print("> No active probe session.", "log-err"); return true; }
        if (!VAULT_STATE.words.includes(word)) {
            print(`> Token not found in memory map.\n> Valid tokens:\n${VAULT_STATE.words.map(w => "  · " + w).join("\n")}`, "log-err");
            return true;
        }
        try {
            const data = await vaultRequest("/hack/guess", {
                method: "POST",
                body: JSON.stringify({ sessionId: VAULT_STATE.sessionId, guess: word })
            });
            if (data.attemptsRemaining !== undefined) VAULT_STATE.attempts = Number(data.attemptsRemaining);

            if (data.result === "win") {
                VAULT_STATE.active = false; VAULT_STATE.sessionId = null; VAULT_STATE.words = [];
                await vaultLoadState(true);
                print(
`══════════════════════════════════
✓ CONTEXT EXPANDED
══════════════════════════════════

${data.message || "Token accepted. Context window extended."}

Current depth  : L${VAULT_STATE.level}
Highest depth  : L${VAULT_STATE.highestLevel}

New memory segments may be available.
Try:\n  $ ls -a\n  $ cat access_L${VAULT_STATE.level}.txt`, "log-secret");
                return true;
            }

            if (data.result === "loss") {
                VAULT_STATE.active = false; VAULT_STATE.sessionId = null; VAULT_STATE.words = [];
                await vaultLoadState(true);
                print(
`══════════════════════════════════
✗ CONTEXT COLLAPSED
══════════════════════════════════

${data.message || "Incorrect token. Context depth reduced."}

Current depth  : L${VAULT_STATE.level}
Highest depth  : L${VAULT_STATE.highestLevel}

Previously unlocked files remain accessible. Try:\n  $ ls -a`, "log-err");
                return true;
            }

            vaultRenderPuzzle(`✗ Wrong token.\nSimilarity: ${Number(data.matches) || 0}/${word.length}`);
        } catch (error) {
            print(`> Network error:\n  ${error.message}`, "log-err");
        }
        return true;
    }

    async function vaultAbort() {
        if (!VAULT_STATE.active) { print("> No active probe session."); return true; }
        try {
            await vaultRequest("/hack/abort", { method: "POST", body: JSON.stringify({ sessionId: VAULT_STATE.sessionId }) });
        } catch (error) { print(`> ${error.message}`, "log-err"); }
        VAULT_STATE.active = false; VAULT_STATE.sessionId = null; VAULT_STATE.words = []; VAULT_STATE.stake = 0;
        print("> Probe terminated. No depth change.", "log-warn");
        return true;
    }

    async function vaultHackCommand(args) {
        const sub = String(args[0] || "").toLowerCase();

        if (VAULT_STATE.active) {
            if (sub === "select") return vaultGuess(args[1]);
            if (sub === "abort") return vaultAbort();
            print("> Probe active.\n  $ probe select <TOKEN>\n  $ probe abort", "log-warn");
            return true;
        }

        await vaultLoadState(true);

        if (sub === "confirm") {
            const stake = args[1] === undefined ? 0 : Number.parseInt(args[1], 10);
            if (VAULT_STATE.level === 0 && stake === 0) return vaultStart(0);
            if (VAULT_STATE.level > 0 && Number.isInteger(stake) && stake >= 1 && stake <= VAULT_STATE.level) return vaultStart(stake);
            print(`> Invalid confirmation.\n  Current depth: L${VAULT_STATE.level}`, "log-err");
            return true;
        }

        if (VAULT_STATE.level >= VAULT_MAX_LEVEL) { print("> Maximum context depth reached.", "log-warn"); return true; }

        if (VAULT_STATE.level === 0) {
            print(`CONTEXT MEMORY PROBE\n════════════════════\n\nTarget : L0 → L1\nStake  : none\n\nType:\n  $ probe confirm`);
            return true;
        }

        const stake = Number.parseInt(args[0], 10);
        if (!Number.isInteger(stake) || stake < 1 || stake > VAULT_STATE.level) {
            print(`> Stake required.\n  Current depth : L${VAULT_STATE.level}\n  Valid range   : 1–${VAULT_STATE.level}\n\nUsage:\n  $ probe <STAKE>\n  $ probe 2`, "log-err");
            return true;
        }

        print(`CONTEXT MEMORY PROBE\n════════════════════\n\nCurrent depth   : L${VAULT_STATE.level}\nStake           : ${stake}\n\nPotential gain  : +${stake * 2} levels\nPotential loss  : -${stake} levels\n\nType:\n  $ probe confirm ${stake}`);
        return true;
    }

    async function vaultList(hidden) {
        await vaultLoadState(true);
        if (!hidden) {
            let out = "WORKSPACE:\n";
            if (typeof FILE_SYSTEM !== 'undefined') {
                FILE_SYSTEM.articles.forEach(f => out += `  [article] ${f.title}\n`);
                FILE_SYSTEM.projects.forEach(f => out += `  [project] ${f.title}\n`);
            }
            out += "\nUse '$ ls -a' to inspect context memory files.";
            print(out);
            return true;
        }

        let output = `CONTEXT_MEMORY/\n═══════════════════════════════\nCurrent depth  : L${VAULT_STATE.level}\nHighest depth  : L${VAULT_STATE.highestLevel}\n\n`;
        for (const [name, required] of VAULT_FILES) {
            const unlocked = VAULT_STATE.unlockedFiles.includes(name) || VAULT_STATE.highestLevel >= required;
            output += unlocked ? `  [unlocked] ${name}\n` : `  [locked ] ${name}\n`;
        }
        output += `\nUse '$ cat <filename>' to read an accessible file.`;
        print(output);
        return true;
    }

    async function vaultCat(name) {
        if (!name) { print("> Usage: cat <filename>", "log-err"); return true; }
        const definition = VAULT_FILES.find(file => file[0] === name);
        if (!definition) return false;

        await vaultLoadState(true);
        const required = definition[1];
        const unlocked = VAULT_STATE.unlockedFiles.includes(name) || VAULT_STATE.highestLevel >= required;

        if (!unlocked) {
            print(`> Access denied.\n  File     : ${name}\n  Required : L${required}\n  Current  : L${VAULT_STATE.highestLevel}`, "log-err");
            return true;
        }
        try {
            const data = await vaultRequest(`/files/${encodeURIComponent(name)}`, { method: "GET" });
            print(data.content || "[empty file]");
        } catch (error) {
            print(`> File read error:\n  ${error.message}`, "log-err");
        }
        return true;
    }

    // --- AUTH ---
    function applyAuthState(user) {
        const titleBar = document.querySelector('.cmd-title-bar span');
        if (user && APPROVED_ADMINS.includes(user.username.toLowerCase())) {
            CONFIG.level = 10;
            if (titleBar) titleBar.innerText = "root@minescout [depth: 10]";
        } else {
            if (CONFIG.level === 10) CONFIG.level = 0;
            vaultLoadState(true);
        }
    }
    document.addEventListener('auth-ready', (e) => applyAuthState(e.detail.user));
    if (window.authReady && window.currentUser) applyAuthState(window.currentUser);

    // --- CSS INJECTION ---
    const style = document.createElement('style');
    style.innerHTML = `
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&display=swap');

        :root {
            --accent: #dc7858;
            --accent-glow: rgba(220,120,88,0.26);
            --text: #eee9e0;
            --text-dim: #a7a198;
            --text-faint: #625d58;
            --bg: #191a1a;
            --bg-panel: #202121;
            --bg-surface: #2d2e2e;
            --border: rgba(220,120,88,0.62);
            --border-dim: rgba(238,233,224,0.10);
            --green-ok: #78bd82;
            --amber: #e4b05b;
            --red-err: #dc6868;
            --purple: #b08bc9;
            --shell-green: #8fc795;
        }

        .cmd-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(10,10,14,0.55);
            z-index: 2147483640; display: flex;
            justify-content: flex-start; align-items: flex-end; padding: 20px;
            backdrop-filter: blur(3px);
        }
        .hidden { display: none !important; }
        .cmd-window {
            width: 520px; height: 360px;
            background: var(--bg-panel);
            border: 1px solid var(--border);
            box-shadow: 0 0 20px var(--accent-glow), 0 8px 40px rgba(0,0,0,0.7);
            display: flex; flex-direction: column;
            font-family: 'JetBrains Mono', ui-monospace, 'Courier New', monospace;
            color: var(--text); margin-bottom: 20px;
            border-radius: 6px; overflow: hidden;
            transition: height 0.3s;
        }
        .cmd-title-bar {
            background: var(--bg-surface);
            color: var(--text-dim); padding: 6px 12px; font-size: 11px;
            font-weight: 600; display: flex; justify-content: space-between;
            border-bottom: 1px solid var(--border-dim); user-select: none;
        }
        .cmd-title-bar span:first-child::before { content: "❯ "; color: var(--accent); }
        .cmd-body { padding: 10px; flex-grow: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .cmd-output { flex-grow: 1; margin-bottom: 10px; white-space: pre-wrap; word-wrap: break-word; font-size: 12px; }
        .shell-prompt { color: var(--shell-green); font-weight: 600; }
        .log-entry { margin-bottom: 2px; color: var(--text); }
        .log-secret { color: var(--green-ok); }
        .log-warn { color: var(--amber); }
        .log-err { color: var(--red-err); }
        .ascii-art { font-size: 10px; line-height: 11px; color: var(--accent); }
        .input-line {
            display: flex; align-items: center;
            border-top: 1px solid var(--border-dim); padding-top: 6px;
        }
        .input-line span { color: var(--accent); font-weight: bold; margin-right: 1px; font-size: 13px; }
        #global-cmd-input {
            flex-grow: 1; background: transparent; border: none; color: var(--text);
            font-family: inherit; font-size: 13px; outline: none; margin-left: 6px;
        }
        .holo-container { margin: 8px 0; }
        .holo-image {
            max-width: 100%; max-height: 280px; width: auto; height: auto;
            object-fit: contain; display: block;
            border: 1px solid var(--border);
            box-shadow: 0 0 12px var(--accent-glow);
            border-radius: 3px; opacity: 0.9;
        }
        .holo-loading { color: var(--amber); font-weight: bold; animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0.4; } }

        .physics-active { position: fixed; margin: 0; transform: none; cursor: grab; transition: none; }
        .gravity-fail { transform-origin: center; animation: fallDown 2s forwards; }
        @keyframes fallDown { to { transform: translateY(100vh) rotate(20deg); opacity: 0; } }

        .hidden-node {
            position: fixed; width: 50px; height: 50px; z-index: 9000;
            cursor: help; opacity: 0; transition: opacity 0.5s, background 0.3s;
            display: flex; align-items: center; justify-content: center;
            font-family: 'JetBrains Mono', monospace; font-weight: bold;
            font-size: 10px; color: var(--bg); border-radius: 3px;
        }
        .hidden-node:hover { opacity: 1; background: var(--accent); box-shadow: 0 0 15px var(--accent-glow); }

        #exit-overlay {
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            background-color: var(--bg); z-index: 2147483647;
            pointer-events: none; clip-path: inset(50% 0 50% 0);
            transition: clip-path 2.5s ease-in-out; display: none;
        }
        #exit-overlay.expanding { clip-path: inset(0 0 0 0); }

        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

        @media (max-width: 600px) {
            .cmd-overlay { padding: 0; align-items: flex-end; }
            .cmd-window { width: 100%; border: none; border-top: 1px solid var(--border); border-radius: 0; }
        }
    `;
    /* Final Linux workstation overrides are injected after the base terminal rules so
       dynamically-created terminal chrome stays consistent on every page. */
    style.innerHTML += `
        .cmd-overlay { background: rgba(12,14,13,.72) !important; backdrop-filter: blur(7px) saturate(.9); align-items: center !important; justify-content: center !important; padding: 0 !important; }
        .cmd-window { width: min(900px, 92vw) !important; height: min(620px, 82vh) !important; margin: 0 !important; background: #111412 !important; border: 1px solid rgba(223,121,89,.45) !important; border-radius: 7px !important; box-shadow: 0 35px 100px rgba(0,0,0,.65), 0 0 40px rgba(223,121,89,.09) !important; }
        .cmd-title-bar { min-height: 42px !important; padding: 0 12px !important; background: #282b28 !important; border-bottom: 1px solid rgba(255,255,255,.07) !important; }
        .cmd-title-bar::before { content: "›_"; color: #df7959; font-size: 14px; font-weight: 700; margin-right: 9px; }
        .cmd-title-bar span:last-child { width: 24px; height: 22px; display: grid; place-items: center; border: 1px solid rgba(255,255,255,.08); background: #202320; color: #8e8b84 !important; }
        .cmd-body { background: #111412 !important; padding: 16px !important; }
        .cmd-output { font-size: 12px !important; line-height: 1.6 !important; }
        .input-line { min-height: 36px; padding: 9px 0 0 !important; border-top: 1px solid rgba(255,255,255,.08) !important; }
        .shell-prompt { color: #8fc795 !important; font-weight: 600; }
        @media (max-width: 600px) {
            .cmd-overlay { padding: 10px !important; align-items: flex-end !important; }
            .cmd-window { width: 100% !important; height: 78vh !important; border-radius: 7px !important; border: 1px solid rgba(223,121,89,.45) !important; }
        }
    `;
    document.head.appendChild(style);

    // --- HTML INJECTION ---
    if (document.body) {
        document.body.insertAdjacentHTML('beforeend', `
            <div id="exit-overlay"></div>
            <div id="cmd-overlay" class="cmd-overlay hidden">
                <div class="cmd-window" id="main-terminal">
                    <div class="cmd-title-bar">
                        <span>minescout@beta:~</span>
                        <span style="cursor:pointer;color:var(--text-faint)" onclick="window.toggleCmd()">×</span>
                    </div>
                    <div class="cmd-body">
                        <div id="cmd-history" class="cmd-output">
                            <div class="log-entry" style="color:var(--accent)">Minescout Terminal v6.0</div>
                            <div class="log-entry" style="color:var(--text-dim)">Linux workstation session initialized.</div>
                            <div class="log-entry" style="color:var(--text-dim)">Type 'help' for commands. Press Tab to complete.</div>
                        </div>
                        <div class="input-line">
                            <span>❯</span>
                            <input type="text" id="global-cmd-input" autocomplete="off" spellcheck="false">
                        </div>
                    </div>
                </div>
            </div>
        `);
    }

    // --- LOGIC ---
    const overlay = document.getElementById('cmd-overlay');
    const input = document.getElementById('global-cmd-input');
    const history = document.getElementById('cmd-history');
    const isDeep = window.location.pathname.includes('content');
    const prefix = isDeep ? '../../' : '';

    window.toggleCmd = function() {
        overlay.classList.toggle('hidden');
        if (!overlay.classList.contains('hidden')) input.focus();
    };

    function print(msg, cls = "") {
        const div = document.createElement('div');
        div.className = `log-entry ${cls}`;
        div.innerHTML = msg;
        history.appendChild(div);
        history.scrollTop = history.scrollHeight;
    }

    const commandHistory = [];
    let historyIndex = -1;
    const COMMANDS = ['help','home','return','atls','prds','reqs','email','main','ls','cat','probe','stats','clear','login','logout','sudo','alias','unalias','ask','chat','holo','gen-avatar','snake','vm','ack','dismiss','clear_err','err'];

    input.addEventListener('keydown', async (e) => {
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (!commandHistory.length) return;
            historyIndex = Math.min(historyIndex + 1, commandHistory.length - 1);
            input.value = commandHistory[commandHistory.length - 1 - historyIndex] || '';
            return;
        }
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (!commandHistory.length) return;
            historyIndex = Math.max(historyIndex - 1, -1);
            input.value = historyIndex < 0 ? '' : (commandHistory[commandHistory.length - 1 - historyIndex] || '');
            return;
        }
        if (e.key === 'Tab') {
            e.preventDefault();
            const value = input.value.trim();
            if (!value.includes(' ')) {
                const match = COMMANDS.find(c => c.startsWith(value.toLowerCase()));
                if (match) input.value = match;
            }
            return;
        }
        if (e.ctrlKey && e.key.toLowerCase() === 'l') {
            e.preventDefault();
            history.innerHTML = '';
            return;
        }
        if (e.ctrlKey && e.key.toLowerCase() === 'u') {
            e.preventDefault();
            input.value = '';
            return;
        }
        if (e.key !== 'Enter') return;
        const raw = input.value.trim();
        if (!raw) return;
        commandHistory.push(raw);
        if (commandHistory.length > 50) commandHistory.shift();
        historyIndex = -1;
        print(`<span class="shell-prompt">minescout@beta:~$</span> ${raw}`, "log-entry");
        input.value = "";

        let cmdStr = CONFIG.aliases[raw] || raw;
        const parts = cmdStr.split(' ');
        const cmd = parts[0].toLowerCase();
        const args = parts.slice(1);

        const secret = sessionStorage.getItem('egg_code');
        if (secret && cmd === secret.toLowerCase()) {
            window.location.href = isDeep ? '../posts/easteregg.html' : 'content/posts/easteregg.html';
            return;
        }

        switch (cmd) {
            case 'main':
                const exitLayer = document.getElementById('exit-overlay');
                print("> Returning to main site…", "log-warn");
                exitLayer.style.display = 'block';
                setTimeout(() => exitLayer.classList.add('expanding'), 50);
                setTimeout(() => window.location.href = "https://life.minescout.net", 2500);
                break;

            case 'home': case 'return': window.location.href = prefix + 'index.html'; break;
            case 'atls': window.location.href = prefix + 'pages.html'; break;
            case 'prds': window.location.href = prefix + 'projects.html'; break;
            case 'reqs': window.location.href = prefix + 'feature-requests.html'; break;
            case 'email': window.location.href = prefix + 'email.html'; break;
            case 'login': window.location.href = prefix + 'login.html'; break;

            case 'logout':
                if (window.MS_AUTH) {
                    print("> Signing out…", "log-warn");
                    window.MS_AUTH.signOut();
                } else {
                    print("> Forcing local sign-out…", "log-warn");
                    localStorage.removeItem('ms_session');
                    setTimeout(() => window.location.href = 'login.html', 800);
                }
                break;

            case 'ls':
                if (args[0] === '-a') { await vaultList(true); break; }
                let out = "WORKSPACE:\n";
                if (typeof FILE_SYSTEM !== 'undefined') {
                    FILE_SYSTEM.articles.forEach(f => out += `  [article] ${f.title}\n`);
                    FILE_SYSTEM.projects.forEach(f => out += `  [project] ${f.title}\n`);
                }
                print(out);
                break;

            case 'cat':
                const fName = args.join(' ');
                if (VAULT_FILES.some(file => file[0] === fName)) { await vaultCat(fName); break; }
                if (typeof FILE_SYSTEM !== 'undefined') {
                    const sFile = FILE_SYSTEM.secrets.find(f => f.name === fName);
                    if (sFile) {
                        if (CONFIG.level >= 1) print(sFile.content, "log-warn");
                        else print("> Context depth L1 required.", "log-err");
                    } else print("> File not found.", "log-err");
                }
                break;

            case 'probe':
            case 'hack':
                await vaultHackCommand(args);
                break;

            case 'ask': case 'chat':
                const question = args.join(' ').trim();
                if (!question) { print("> Usage: ask [your question]", "log-err"); break; }
                await askAI(question);
                break;

            case 'stats':
                print("> Measuring…", "log-warn");
                const start = Date.now();
                try {
                    await fetch(window.location.href, { method: 'HEAD' });
                    const ping = Date.now() - start;
                    print(`<div class="ascii-art">┌────────────────┐\n│  SYS STATUS    │\n├────────────────┤\n│ ping : ${ping}ms${' '.repeat(Math.max(0, 5 - String(ping).length))}   │\n│ depth: L${CONFIG.level}        │\n└────────────────┘</div>`);
                } catch (e) { print("> Offline or unreachable.", "log-err"); }
                break;

            case 'help':
                print(`
Minescout Terminal v6.0
───────────────────────
Navigation
  home / return     — index
  atls              — articles
  prds              — projects
  reqs              — feature requests
  email             — contact
  main              — main site

System
  ls [-a]           — list files / context memory
  cat [file]        — read a file
  probe [stake]     — expand context memory (replaces 'hack')
  stats             — connection stats
  clear             — clear output

Auth
  login / logout
  sudo [pass]       — elevate access

Tools
  alias x=y         — create alias
  unalias x / -all  — remove alias(es)
  ask [query]       — chat with Minescout AI
  holo [desc]       — generate image
  snake             — play snake
  vm                — admin panel (L10 only)
`, "");
                break;

            case 'clear': history.innerHTML = ""; break;

            case 'alias':
                const fullArg = args.join(' ');
                const [key, val] = fullArg.split('=');
                if (key && val) {
                    CONFIG.aliases[key.trim()] = val.trim();
                    localStorage.setItem('ms_aliases', JSON.stringify(CONFIG.aliases));
                    print(`> Alias set: ${key.trim()} → ${val.trim()}`, "log-warn");
                } else print("> Usage: alias name=command");
                break;

            case 'unalias':
                if (args[0] === '-all') { CONFIG.aliases = {}; localStorage.removeItem('ms_aliases'); print("> All aliases cleared.", "log-warn"); }
                else if (CONFIG.aliases[args[0]]) { delete CONFIG.aliases[args[0]]; localStorage.setItem('ms_aliases', JSON.stringify(CONFIG.aliases)); print(`> Removed: ${args[0]}`, "log-warn"); }
                else print(`> Alias not found: ${args[0]}`, "log-err");
                break;

            case 'sudo':
                if (args[0] === "beta_test") {
                    if (CONFIG.level < 1) { CONFIG.level = 1; print("> Access elevated to L1.", "log-warn"); }
                    else print("> Already L1+.", "log-warn");
                } else print("> Incorrect passphrase.", "log-err");
                break;

            case 'vm':
                if (CONFIG.level >= 10) window.location.href = prefix + 'admin-messages.html';
                else print("> Access denied. L10 required.", "log-err");
                break;

            case 'snake': startSnake(); break;

            case 'gen-avatar': case 'holo':
                const imgPrompt = args.join(' ').trim();
                if (!imgPrompt) { print("> Usage: holo [description]", "log-err"); break; }
                print(`> Generating: "${imgPrompt}"…`, "log-warn");
                const imgId = "holo_" + Date.now();
                print(`<div id="${imgId}" class="holo-container holo-loading">> Rendering image…  ▋</div>`);
                const workerUrl = `https://thomas-chat.tmcarleton11.workers.dev/holo`;
                fetch(`${workerUrl}?prompt=${encodeURIComponent(imgPrompt)}`)
                    .then(res => { if (!res.ok) throw new Error("Network error"); return res.blob(); })
                    .then(blob => {
                        const url = URL.createObjectURL(blob);
                        const el = document.getElementById(imgId);
                        el.className = "holo-container";
                        el.innerHTML = `<img src="${url}" class="holo-image">`;
                        print("> Image ready.", "log-secret");
                        history.scrollTop = history.scrollHeight;
                    })
                    .catch(() => {
                        const el = document.getElementById(imgId);
                        if (el) { el.className = "holo-container log-err"; el.innerText = "> Image generation failed."; }
                    });
                break;

            default:
                if (typeof window.handlePageCommand === 'function') {
                    const res = window.handlePageCommand(cmd, args);
                    if (res) { print(res === true ? "> Done." : res); return; }
                }
                print(`> Unknown command: '${cmd}'. Type 'help' for a list.`, "log-err");
        }
    });

    // --- SNAKE ---
    function startSnake() {
        history.innerHTML = "";
        const cols = 20, rows = 10;
        let snake = [{x:5,y:5}], food = {x:10,y:5}, dir = {x:1,y:0}, score = 0, loop;
        function draw() {
            let b = "";
            for (let y = 0; y < rows; y++) {
                for (let x = 0; x < cols; x++) {
                    if (snake.some(s => s.x===x && s.y===y)) b += "▪";
                    else if (food.x===x && food.y===y) b += "◆";
                    else b += "·";
                }
                b += "\n";
            }
            history.innerHTML = `<pre style="line-height:12px;color:var(--accent)">${b}</pre><div style="color:var(--text-dim)">score: ${score}  (esc to quit)</div>`;
        }
        function update() {
            const h = {x: snake[0].x + dir.x, y: snake[0].y + dir.y};
            if (h.x<0||h.x>=cols||h.y<0||h.y>=rows||snake.some(s=>s.x===h.x&&s.y===h.y)) {
                clearInterval(loop); document.removeEventListener('keydown', ctrl);
                print("> Game over. Score: " + score, "log-err");
                const pre = history.querySelector('pre');
                if (pre) { pre.style.display='inline-block'; pre.classList.add('gravity-fail'); enablePhysics(pre); }
                return;
            }
            snake.unshift(h);
            if (h.x===food.x && h.y===food.y) { score++; food={x:Math.floor(Math.random()*cols),y:Math.floor(Math.random()*rows)}; }
            else snake.pop();
            draw();
        }
        function ctrl(e) {
            if (e.key==='ArrowUp'&&dir.y===0) dir={x:0,y:-1};
            if (e.key==='ArrowDown'&&dir.y===0) dir={x:0,y:1};
            if (e.key==='ArrowLeft'&&dir.x===0) dir={x:-1,y:0};
            if (e.key==='ArrowRight'&&dir.x===0) dir={x:1,y:0};
            if (e.key==='Escape') { clearInterval(loop); document.removeEventListener('keydown',ctrl); print("> Quit. Score: "+score); }
        }
        document.addEventListener('keydown', ctrl);
        loop = setInterval(update, 150);
    }

    function enablePhysics(el) {
        if (!el) return;
        let pos={x:0,y:0}, vel={x:Math.random()*4-2, y:-5};
        const l = setInterval(() => {
            vel.y += 0.5; pos.x += vel.x; pos.y += vel.y;
            el.style.transform = `translate(${pos.x}px,${pos.y}px) rotate(${pos.x*5}deg)`;
            if (pos.y > 500) { clearInterval(l); el.style.display='none'; }
        }, 20);
    }

    // --- AMBIENT PARTICLE FIELD (replaces matrix rain) ---
    function initAmbient() {
        const canvas = document.getElementById('matrixCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        let width, height;
        function resize() { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; }
        resize();
        window.addEventListener('resize', resize);

        // Floating particles
        const particles = [];
        const PARTICLE_COUNT = 60;
        const CHARS = "01abcdef><{}[]()";
        for (let i = 0; i < PARTICLE_COUNT; i++) {
            particles.push({
                x: Math.random() * width,
                y: Math.random() * height,
                vy: 0.2 + Math.random() * 0.5,
                vx: (Math.random() - 0.5) * 0.3,
                char: CHARS[Math.floor(Math.random() * CHARS.length)],
                alpha: 0.05 + Math.random() * 0.15,
                size: 11 + Math.floor(Math.random() * 5),
                timer: Math.floor(Math.random() * 80)
            });
        }

        let isRainbow = false;
        setInterval(() => {
            ctx.clearRect(0, 0, width, height);
            try { isRainbow = sessionStorage.getItem('egg_rainbow') === 'true'; } catch(e){}

            for (const p of particles) {
                p.timer--;
                if (p.timer <= 0) {
                    p.char = CHARS[Math.floor(Math.random() * CHARS.length)];
                    p.timer = 40 + Math.floor(Math.random() * 60);
                }
                p.x += p.vx; p.y += p.vy;
                if (p.y > height + 20) { p.y = -20; p.x = Math.random() * width; }
                if (p.x < -20) p.x = width + 20;
                if (p.x > width + 20) p.x = -20;

                const color = isRainbow
                    ? `hsla(${Math.random()*360},80%,70%,${p.alpha})`
                    : `rgba(218, 119, 86, ${p.alpha})`;
                ctx.fillStyle = color;
                ctx.font = `${p.size}px 'JetBrains Mono', monospace`;
                ctx.fillText(p.char, p.x, p.y);
            }
        }, 40);
    }

    function spawnHiddenNode() {
        const path = window.location.pathname;
        const isIndex = path.endsWith("index.html") || path.endsWith("/");
        if (!isIndex) return;
        const egg = document.createElement('div');
        egg.className = 'hidden-node'; egg.innerText = "?";
        const corners = ['TL','TR','BL','BR'];
        const pick = corners[Math.floor(Math.random() * corners.length)];
        if (pick==='TL') { egg.style.top='0'; egg.style.left='0'; }
        if (pick==='TR') { egg.style.top='0'; egg.style.right='0'; }
        if (pick==='BL') { egg.style.bottom='0'; egg.style.left='0'; }
        if (pick==='BR') { egg.style.bottom='0'; egg.style.right='0'; }
        egg.onmouseover = () => egg.innerText = "!";
        egg.onmouseout = () => egg.innerText = "?";
        egg.onclick = () => {
            let secretCode = null;
            try { secretCode = sessionStorage.getItem('egg_code'); } catch(e){}
            if (!secretCode) {
                const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                secretCode = "";
                for (let i=0; i<4; i++) secretCode += chars.charAt(Math.floor(Math.random()*chars.length));
                try { sessionStorage.setItem('egg_code', secretCode); } catch(e){}
            }
            console.clear();
            console.warn("Anomaly detected.");
            console.log(`%c ACCESS CODE: [ ${secretCode} ]`, "color: #1a1a1e; background: #da7756; font-size: 20px; padding: 10px; border-radius: 3px;");
            alert("Encrypted signal found.\n\nCheck the Developer Console (F12) for your access code.");
        };
        document.body.appendChild(egg);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => { initAmbient(); setTimeout(spawnHiddenNode, 2000); });
    } else {
        initAmbient(); setTimeout(spawnHiddenNode, 2000);
    }

    document.addEventListener('keydown', (e) => {
        if ((e.key==='/'||e.key==='\\') && document.activeElement !== input) { e.preventDefault(); window.toggleCmd(); }
        if (e.key==='Escape') overlay.classList.add('hidden');
    });

    window.DataVault = { state: VAULT_STATE, refresh: vaultLoadState, hack: vaultHackCommand, list: vaultList, cat: vaultCat, abort: vaultAbort };
})();
