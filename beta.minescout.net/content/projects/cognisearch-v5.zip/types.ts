export interface Article {
  id: string;
  title: string;
  url: string;
  source: string;
  summary: string;
  biasRating: 'Low' | 'Moderate' | 'High' | 'Unknown';
  trustScore: number; // 1-100
  publishedDate?: string;
}

export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
}

export interface SearchResult {
  articles: Article[];
  rawText: string;
}

export interface SavedReport {
  id: string;
  title: string;
  content: string; // Markdown
  dateCreated: number;
  sources: Article[];
}

export interface UserProfile {
  username: string;
  joinedDate: number;
  savedReports: SavedReport[];
  searchHistory: string[];
}

export type AppMode = 'search' | 'synthesis' | 'saved' | 'profile';

export type DateRange = 'any' | 'day' | 'week' | 'month' | 'year';
export type SourceType = 'all' | 'news' | 'academic' | 'official';

export interface SearchFilters {
  dateRange: DateRange;
  sourceType: SourceType;
  minTrustScore: number;
}

export interface SynthesisOptions {
  additionalInstructions: string;
  tone: 'Professional' | 'Academic' | 'Casual' | 'Executive';
  format: 'General Overview' | 'Key Points' | 'Comparative Analysis';
  length: 'Short' | 'Medium' | 'Long';
}