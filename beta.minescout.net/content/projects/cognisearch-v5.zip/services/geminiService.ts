import { GoogleGenAI } from "@google/genai";
import { Article, SearchResult, SearchFilters, SynthesisOptions } from "../types";

const getClient = () => {
  // Check local storage first (for standalone use outside the IDE environment)
  const localKey = typeof window !== 'undefined' ? window.localStorage.getItem('gemini_api_key') : null;
  if (localKey) {
      return new GoogleGenAI({ apiKey: localKey });
  }

  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API_KEY not found. Please click the Key icon in the sidebar to configure your API key.");
  return new GoogleGenAI({ apiKey });
};

// Helper to clean messy grounding URLs and remove google redirects
const cleanUrl = (url: string): string => {
  if (!url) return "";
  try {
    // Decode if it's a google redirect
    if (url.includes('google.com/url')) {
      const urlObj = new URL(url);
      const q = urlObj.searchParams.get('q');
      if (q) return decodeURIComponent(q);
    }
    
    // If it is a Vertex AI Search link, it often contains the real link in 'url' param or similar, 
    // but if not, we can't easily fix it. However, blocking it entirely causes "No articles found".
    // We will return it as is if we can't clean it, so at least the user sees *something*.
    
    return url;
  } catch (e) {
    return url;
  }
};

export const searchArticles = async (query: string, filters?: SearchFilters): Promise<SearchResult> => {
  const ai = getClient();
  
  let filterInstructions = "";
  if (filters) {
      if (filters.sourceType === 'academic') {
          filterInstructions += "Focus strictly on academic papers, research journals, and .edu domains. ";
      } else if (filters.sourceType === 'official') {
          filterInstructions += "Focus on official government reports, legal documents, and .gov domains. ";
      } else if (filters.sourceType === 'news') {
          filterInstructions += "Focus on major, reputable news outlets. ";
      }

      if (filters.dateRange !== 'any') {
          const rangeMap: Record<string, string> = {
              'day': 'published within the last 24 hours',
              'week': 'published within the last 7 days',
              'month': 'published within the last 30 days',
              'year': 'published within the last 365 days'
          };
          filterInstructions += `Find results ${rangeMap[filters.dateRange] || 'recently'}. `;
      }

      if (filters.minTrustScore > 0) {
          filterInstructions += "Prioritize sources with high credibility and trustworthiness. ";
      }
  }

  // We removed responseMimeType: "application/json" because it conflicts with tools in some contexts.
  // Instead, we explicitly ask for JSON in the prompt and clean the output.
  const prompt = `
    Task: Find 6 distinct ${filterInstructions} news articles or sources about: "${query}".
    
    You MUST use the 'googleSearch' tool to find real, verifiable URLs.
    
    After searching, return a RAW JSON object (do not add markdown formatting if possible) with the following structure:
    {
      "articles": [
        {
          "title": "string",
          "url": "string", 
          "source": "string",
          "summary": "string",
          "trustScore": number,
          "biasRating": "string"
        }
      ]
    }

    IMPORTANT: 
    - The "url" field is CRITICAL. You must extract it from the search results. 
    - Do not make up URLs. 
    - If you cannot find 6, return as many as you found.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        // responseMimeType: "application/json", // Removed to fix 400 error
        temperature: 0.1,
      },
    });

    const text = response.text || "{}";
    let parsedArticles: Article[] = [];
    
    try {
        // Strip markdown code blocks (```json ... ```) if the model adds them
        const jsonString = text.replace(/```json\n?|\n?```/g, "").trim();
        const json = JSON.parse(jsonString);

        if (json.articles && Array.isArray(json.articles)) {
            parsedArticles = json.articles.map((item: any, index: number) => ({
                id: `json-${index}-${Date.now()}`,
                title: item.title || "Untitled",
                url: cleanUrl(item.url || ""),
                source: item.source || "Web",
                summary: item.summary || "No summary available.",
                trustScore: typeof item.trustScore === 'number' ? item.trustScore : 70,
                biasRating: item.biasRating || "Unknown"
            }));
        }
    } catch (e) {
        console.warn("JSON parse failed, falling back to manual extraction", e);
    }

    // Backup: If JSON parsing failed or returned empty URL placeholders, check GroundingMetadata
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const groundingArticles: Article[] = chunks.map((chunk, index) => {
        const rawUrl = chunk.web?.uri || "";
        const url = cleanUrl(rawUrl);
        const title = chunk.web?.title || "News Source";
        
        if (!url) return null;

        let source = "Web";
        try { source = new URL(url).hostname.replace('www.', ''); } catch (e) {}

        return {
            id: `chunk-${index}-${Date.now()}`,
            title: title,
            url: url,
            source: source,
            summary: "Source identified via Google Search.",
            trustScore: 80,
            biasRating: 'Unknown',
        } as Article;
    }).filter((a): a is Article => a !== null);

    // Merge: Prefer JSON results (better metadata) but fill in with Grounding results if needed
    // We dedup based on URL
    const mergedMap = new Map<string, Article>();

    // First add Grounding articles (ground truth)
    groundingArticles.forEach(a => mergedMap.set(a.url, a));

    // Then add/overwrite with Parsed articles (better descriptions) if the URL matches or is new
    parsedArticles.forEach(a => {
        if (a.url && a.url.startsWith('http')) {
             mergedMap.set(a.url, a);
        }
    });

    const finalArticles = Array.from(mergedMap.values());

    return { 
        articles: finalArticles.length > 0 ? finalArticles : groundingArticles, 
        rawText: text 
    };

  } catch (error) {
    console.error("Search failed:", error);
    throw error;
  }
};

export const synthesizeReport = async (
  topic: string, 
  articles: Article[],
  options?: SynthesisOptions
): Promise<string> => {
  const ai = getClient();
  
  const sourcesText = articles.map((a, i) => `Source ${i+1}: ${a.title} - ${a.summary} (URL: ${a.url})`).join("\n");

  let customizationPrompt = "";
  if (options) {
      customizationPrompt = `
      CUSTOMIZATION INSTRUCTIONS:
      - Tone: ${options.tone}
      - Format: ${options.format}
      - Length: ${options.length} (Adjust word count accordingly)
      - Additional Instructions: ${options.additionalInstructions}
      `;
  }

  const prompt = `
    You are an expert research analyst.
    Topic: "${topic}"
    
    Using the following sources, write a comprehensive, well-structured research report.
    
    Sources:
    ${sourcesText}

    ${customizationPrompt}
    
    Guidelines:
    1. Use Markdown formatting (headers, bullet points, bold text).
    2. Start with an Executive Summary.
    3. Analyze different perspectives if present in the sources.
    4. Conclude with a "Future Outlook" or "Key Takeaways" section.
    5. Do not include raw URLs in the text, use [Source Name] format.
    6. Ensure the tone is consistent with the request.
    7. If the sources contradict, mention the discrepancy.
    
    Output ONLY the markdown content.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash", 
    contents: prompt,
    config: {
        thinkingConfig: { thinkingBudget: 1024 } 
    }
  });

  return response.text || "Failed to generate report.";
};