import React, { useState, useEffect } from 'react';
import { Search, Sparkles, BookOpen, Clock, AlertTriangle, ArrowRight, Loader2, Library, User, LogOut, LayoutDashboard, History, FileText, Key, X, Check, Filter, Calendar, Globe, Shield, Settings2, FileEdit } from 'lucide-react';
import { Article, AppMode, SearchResult, SavedReport, UserProfile, SearchFilters, SynthesisOptions } from './types';
import * as GeminiService from './services/geminiService';
import { NewsCard } from './components/NewsCard';
import { ReportViewer } from './components/ReportViewer';

// --- LocalStorage Hook ---
function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.log(error);
      return initialValue;
    }
  });
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.log(error);
    }
  };
  return [storedValue, setValue] as const;
}

export default function App() {
  // Auth & Profile State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authInput, setAuthInput] = useState('');
  const [isAuthOpen, setIsAuthOpen] = useState(true);

  // App State
  const [mode, setMode] = useState<AppMode>('search');
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [articles, setArticles] = useState<Article[]>([]);
  const [selectedArticleIds, setSelectedArticleIds] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);
  
  // Filters
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    dateRange: 'any',
    sourceType: 'all',
    minTrustScore: 0
  });

  // API Key Modal State
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  
  // Synthesis State
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [report, setReport] = useState<{title: string, content: string, isOpen: boolean} | null>(null);
  const [isSynthesisModalOpen, setIsSynthesisModalOpen] = useState(false);
  const [synthesisOptions, setSynthesisOptions] = useState<SynthesisOptions>({
    additionalInstructions: '',
    tone: 'Professional',
    format: 'General Overview',
    length: 'Medium'
  });
  
  // Persistent Storage Keyed by User
  const [userDb, setUserDb] = useLocalStorage<Record<string, UserProfile>>('cognisearch_db_v1', {});

  // Effect to load user data when current user changes
  useEffect(() => {
    if (currentUser) {
       // Refresh local articles/reports from the DB if needed, 
       // but for simplicity we just read from currentUser which is kept in sync
    }
  }, [currentUser]);

  // Auth Handlers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authInput.trim()) return;
    
    const username = authInput.trim().toLowerCase();
    
    if (userDb[username]) {
        setCurrentUser(userDb[username]);
    } else {
        // Create new user
        const newUser: UserProfile = {
            username: username,
            joinedDate: Date.now(),
            savedReports: [],
            searchHistory: []
        };
        const updatedDb = { ...userDb, [username]: newUser };
        setUserDb(updatedDb);
        setCurrentUser(newUser);
    }
    setIsAuthOpen(false);
    setMode('search');
  };

  const handleLogout = () => {
      setCurrentUser(null);
      setArticles([]);
      setQuery('');
      setIsAuthOpen(true);
      setAuthInput('');
  };

  const updateUserProfile = (updater: (user: UserProfile) => UserProfile) => {
      if (!currentUser) return;
      const updated = updater({ ...currentUser });
      setCurrentUser(updated);
      setUserDb(prev => ({ ...prev, [updated.username]: updated }));
  };

  // Search Handlers
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    setArticles([]);
    setSelectedArticleIds(new Set());

    try {
      const result: SearchResult = await GeminiService.searchArticles(query, filters);
      if (result.articles.length === 0) {
        setError("No verifiable articles found with these criteria. Try adjusting your filters.");
      } else {
        setArticles(result.articles);
        // Save to history
        updateUserProfile(user => ({
            ...user,
            searchHistory: [query, ...user.searchHistory].slice(0, 10)
        }));
      }
    } catch (err: any) {
      setError("Network error or API limit reached. Please check your connection and API key.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSelection = (id: string) => {
    const next = new Set(selectedArticleIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedArticleIds(next);
  };

  const initiateSynthesis = () => {
     if (selectedArticleIds.size === 0) {
        setError("Please select at least one article source.");
        return;
    }
    setIsSynthesisModalOpen(true);
  };

  const handleSynthesize = async () => {
    setIsSynthesisModalOpen(false);
    setIsSynthesizing(true);
    setError(null);

    try {
        const selectedDocs = articles.filter(a => selectedArticleIds.has(a.id));
        const content = await GeminiService.synthesizeReport(query, selectedDocs, synthesisOptions);
        
        setReport({
            title: query,
            content: content,
            isOpen: true
        });
    } catch (err) {
        setError("Synthesis failed. The AI model might be busy or your API key is invalid.");
    } finally {
        setIsSynthesizing(false);
    }
  };

  const saveCurrentReport = () => {
      if (!report || !currentUser) return;
      
      const newSaved: SavedReport = {
          id: Date.now().toString(),
          title: report.title,
          content: report.content,
          dateCreated: Date.now(),
          sources: articles.filter(a => selectedArticleIds.has(a.id))
      };
      
      updateUserProfile(user => ({
          ...user,
          savedReports: [newSaved, ...user.savedReports]
      }));
      alert("Report saved to your profile!");
  };

  const loadSavedReport = (saved: SavedReport) => {
      setReport({
          title: saved.title,
          content: saved.content,
          isOpen: true
      });
      setArticles(saved.sources || []); 
  };

  const handleApiKeySelect = async () => {
    // 1. Try environment/platform specific picker first
    const aiStudio = (window as any).aistudio;
    if (aiStudio?.openSelectKey) {
        try {
            await aiStudio.openSelectKey();
            return;
        } catch (e) {
            console.warn("AI Studio key picker failed/cancelled, falling back to manual input.");
        }
    }
    
    // 2. Fallback to manual input modal for standalone usage
    const currentKey = localStorage.getItem('gemini_api_key') || '';
    setApiKeyInput(currentKey);
    setIsKeyModalOpen(true);
  };

  const saveLocalKey = () => {
    if (!apiKeyInput.trim()) {
        localStorage.removeItem('gemini_api_key');
    } else {
        localStorage.setItem('gemini_api_key', apiKeyInput.trim());
    }
    setIsKeyModalOpen(false);
    // Optional: Refresh page to ensure services pick up new key if they cached the old one
    // window.location.reload(); 
    alert("API Key saved locally.");
  };

  // --- Auth Screen ---
  if (isAuthOpen) {
      return (
          <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
              <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-500 to-indigo-500"></div>
                  <div className="flex justify-center mb-6">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-primary-500/20">
                          <BookOpen size={32} className="text-white" />
                      </div>
                  </div>
                  <h1 className="text-3xl font-bold text-center text-white mb-2">CogniSearch</h1>
                  <p className="text-center text-slate-400 mb-8">Your intelligent research companion.</p>
                  
                  <form onSubmit={handleLogin} className="space-y-4">
                      <div>
                          <label className="block text-xs font-medium text-slate-500 uppercase mb-1">Username / ID</label>
                          <input 
                            type="text" 
                            value={authInput}
                            onChange={(e) => setAuthInput(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-primary-500 focus:outline-none transition-all"
                            placeholder="Enter your name..."
                            required
                          />
                      </div>
                      <button 
                        type="submit" 
                        className="w-full bg-primary-600 hover:bg-primary-500 text-white font-medium py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                      >
                          <span>Start Researching</span>
                          <ArrowRight size={18} />
                      </button>
                  </form>
                  
                  <div className="mt-8 pt-6 border-t border-slate-800 text-center text-xs text-slate-500">
                      <p>Data is saved locally to your browser.</p>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <aside className="w-20 md:w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between hidden md:flex z-10 shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-primary-500/20">
              <BookOpen size={18} className="text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 hidden md:block">
              CogniSearch
            </h1>
          </div>

          <div className="mb-6 px-4 py-3 bg-slate-950/50 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-primary-400 font-bold">
                  {currentUser?.username.charAt(0).toUpperCase()}
              </div>
              <div className="hidden md:block overflow-hidden">
                  <div className="text-sm font-medium text-white truncate capitalize">{currentUser?.username}</div>
                  <div className="text-xs text-slate-500">Pro Plan</div>
              </div>
          </div>

          <nav className="space-y-2">
            <button 
                onClick={() => setMode('search')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${mode === 'search' ? 'bg-primary-900/30 text-primary-400 font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`}
            >
              <Search size={20} />
              <span className="hidden md:block">Deep Research</span>
            </button>
            <button 
                onClick={() => setMode('synthesis')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${mode === 'synthesis' ? 'bg-indigo-900/30 text-indigo-400 font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`}
            >
              <Sparkles size={20} />
              <span className="hidden md:block">AI Synthesis</span>
            </button>
            <button 
                onClick={() => setMode('saved')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${mode === 'saved' ? 'bg-green-900/30 text-green-400 font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`}
            >
              <Library size={20} />
              <span className="hidden md:block">Library</span>
            </button>
            <button 
                onClick={() => setMode('profile')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${mode === 'profile' ? 'bg-orange-900/30 text-orange-400 font-medium' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`}
            >
              <User size={20} />
              <span className="hidden md:block">Profile</span>
            </button>
          </nav>
        </div>
        
        <div className="p-6 border-t border-slate-800 flex flex-col gap-3">
             <button 
                onClick={handleApiKeySelect}
                className="flex items-center gap-2 text-slate-500 hover:text-primary-400 transition-colors text-sm w-full"
            >
                <Key size={16} />
                <span className="hidden md:inline">API Key</span>
            </button>
            <button onClick={handleLogout} className="flex items-center gap-2 text-slate-500 hover:text-red-400 transition-colors text-sm w-full">
                <LogOut size={16} />
                <span className="hidden md:inline">Sign Out</span>
            </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Mobile Header */}
        <div className="md:hidden p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900 z-50">
           <span className="font-bold">CogniSearch</span>
           <div className="flex gap-4">
              <Search size={20} onClick={() => setMode('search')} className={mode === 'search' ? 'text-primary-400' : 'text-slate-500'} />
              <Sparkles size={20} onClick={() => setMode('synthesis')} className={mode === 'synthesis' ? 'text-indigo-400' : 'text-slate-500'} />
              <Library size={20} onClick={() => setMode('saved')} className={mode === 'saved' ? 'text-green-400' : 'text-slate-500'} />
              <User size={20} onClick={() => setMode('profile')} className={mode === 'profile' ? 'text-orange-400' : 'text-slate-500'} />
           </div>
        </div>

        {/* View: Profile */}
        {mode === 'profile' && currentUser && (
             <div className="flex-1 overflow-y-auto p-6 md:p-12 custom-scrollbar">
                <div className="max-w-4xl mx-auto">
                    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-8 mb-8">
                        <div className="flex items-center gap-6 mb-6">
                            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-slate-800 to-slate-700 flex items-center justify-center text-3xl font-bold text-white uppercase">
                                {currentUser.username.charAt(0)}
                            </div>
                            <div>
                                <h2 className="text-2xl font-bold capitalize mb-1">{currentUser.username}</h2>
                                <p className="text-slate-400">Member since {new Date(currentUser.joinedDate).toLocaleDateString()}</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 border-t border-slate-800 pt-6">
                            <div className="text-center">
                                <div className="text-2xl font-bold text-white">{currentUser.savedReports.length}</div>
                                <div className="text-xs text-slate-500 uppercase tracking-wider">Reports</div>
                            </div>
                            <div className="text-center border-l border-slate-800">
                                <div className="text-2xl font-bold text-white">{currentUser.searchHistory.length}</div>
                                <div className="text-xs text-slate-500 uppercase tracking-wider">Searches</div>
                            </div>
                            <div className="text-center border-l border-slate-800">
                                <div className="text-2xl font-bold text-white">Pro</div>
                                <div className="text-xs text-slate-500 uppercase tracking-wider">Plan</div>
                            </div>
                        </div>
                    </div>

                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                        <History size={20} className="text-slate-500" />
                        Recent Search History
                    </h3>
                    <div className="space-y-2 mb-12">
                        {currentUser.searchHistory.map((h, i) => (
                            <div key={i} onClick={() => { setQuery(h); setMode('search'); }} className="p-4 bg-slate-900/50 rounded-xl border border-slate-800 hover:bg-slate-800 cursor-pointer transition-colors flex justify-between items-center group">
                                <span className="text-slate-300">{h}</span>
                                <ArrowRight size={16} className="text-slate-600 group-hover:text-primary-400" />
                            </div>
                        ))}
                         {currentUser.searchHistory.length === 0 && (
                            <div className="text-slate-500 text-sm italic">No history yet.</div>
                        )}
                    </div>
                </div>
             </div>
        )}

        {/* View: Saved Library */}
        {mode === 'saved' && currentUser && (
            <div className="flex-1 overflow-y-auto p-6 md:p-12 custom-scrollbar">
                <div className="max-w-6xl mx-auto">
                    <div className="flex items-center gap-4 mb-8">
                        <div className="p-3 bg-green-900/20 rounded-lg">
                            <Library className="text-green-400" size={24} />
                        </div>
                        <div>
                            <h2 className="text-3xl font-bold">Your Library</h2>
                            <p className="text-slate-400">Saved reports and syntheses</p>
                        </div>
                    </div>

                    {currentUser.savedReports.length === 0 ? (
                        <div className="text-center py-20 text-slate-500 bg-slate-900/30 rounded-2xl border border-slate-800 border-dashed">
                            <FileText size={48} className="mx-auto mb-4 opacity-50" />
                            <p>No saved reports yet.</p>
                            <button onClick={() => setMode('search')} className="mt-4 text-primary-400 hover:underline">Start researching</button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {currentUser.savedReports.map(report => (
                                <div key={report.id} onClick={() => loadSavedReport(report)} className="p-6 bg-slate-900 rounded-xl border border-slate-800 hover:border-slate-600 cursor-pointer group transition-all flex flex-col h-64">
                                    <div className="flex-1">
                                        <h3 className="font-bold text-lg mb-2 group-hover:text-primary-400 leading-tight">{report.title}</h3>
                                        <p className="text-slate-400 text-sm line-clamp-4">{report.content.replace(/[#*`]/g, '')}</p>
                                    </div>
                                    <div className="flex justify-between items-center text-xs text-slate-500 pt-4 border-t border-slate-800 mt-4">
                                        <span className="flex items-center gap-1"><Clock size={12}/> {new Date(report.dateCreated).toLocaleDateString()}</span>
                                        <span className="bg-slate-800 px-2 py-1 rounded-full">{report.sources?.length || 0} Sources</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* View: Search & Synthesis */}
        {(mode === 'search' || mode === 'synthesis') && (
            <div className="flex-1 flex flex-col h-full">
                {/* Search Header */}
                <div className="p-6 md:p-12 pb-6 md:pb-8 shrink-0">
                    <div className="max-w-3xl mx-auto text-center">
                        <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
                           {mode === 'search' ? 'Deep Research Engine' : 'AI Knowledge Synthesis'}
                        </h2>
                        
                        <form onSubmit={handleSearch} className="relative group mt-8">
                            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                                <Search className="text-slate-500 group-focus-within:text-primary-500 transition-colors" size={20} />
                            </div>
                            <input
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder={mode === 'search' ? "Search for topics, news, or academic papers..." : "Enter topic to synthesize..."}
                                className="w-full pl-12 pr-14 py-4 bg-slate-900 border border-slate-700 rounded-2xl text-lg focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 transition-all shadow-xl placeholder:text-slate-600"
                            />
                            {mode === 'search' && (
                                <button
                                    type="button"
                                    onClick={() => setShowFilters(!showFilters)}
                                    className={`absolute right-14 top-2 bottom-2 px-3 rounded-xl transition-colors flex items-center gap-2 ${showFilters ? 'bg-primary-900/30 text-primary-400' : 'text-slate-500 hover:text-white'}`}
                                >
                                    <Filter size={18} />
                                </button>
                            )}
                            <button 
                                type="submit" 
                                disabled={isLoading}
                                className="absolute right-2 top-2 bottom-2 bg-slate-800 hover:bg-slate-700 text-white px-4 rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
                            >
                                {isLoading ? <Loader2 className="animate-spin" size={20} /> : <ArrowRight size={20} />}
                            </button>
                        </form>

                        {/* Search Filters */}
                        {showFilters && mode === 'search' && (
                            <div className="mt-4 p-4 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-wrap gap-4 justify-center animate-in slide-in-from-top-2 fade-in">
                                <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
                                    <Calendar size={14} className="text-slate-400" />
                                    <select 
                                        value={filters.dateRange}
                                        onChange={(e) => setFilters({...filters, dateRange: e.target.value as any})}
                                        className="bg-transparent text-sm text-slate-200 focus:outline-none"
                                    >
                                        <option value="any">Any Time</option>
                                        <option value="day">Past 24 Hours</option>
                                        <option value="week">Past Week</option>
                                        <option value="month">Past Month</option>
                                        <option value="year">Past Year</option>
                                    </select>
                                </div>
                                
                                <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
                                    <Globe size={14} className="text-slate-400" />
                                    <select 
                                        value={filters.sourceType}
                                        onChange={(e) => setFilters({...filters, sourceType: e.target.value as any})}
                                        className="bg-transparent text-sm text-slate-200 focus:outline-none"
                                    >
                                        <option value="all">All Sources</option>
                                        <option value="news">News Outlets</option>
                                        <option value="academic">Academic & Research</option>
                                        <option value="official">Official & Gov</option>
                                    </select>
                                </div>

                                <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
                                    <Shield size={14} className="text-slate-400" />
                                    <select 
                                        value={filters.minTrustScore}
                                        onChange={(e) => setFilters({...filters, minTrustScore: Number(e.target.value)})}
                                        className="bg-transparent text-sm text-slate-200 focus:outline-none"
                                    >
                                        <option value={0}>Any Trust Score</option>
                                        <option value={60}>Moderate (60+)</option>
                                        <option value={80}>High (80+)</option>
                                    </select>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Results Area */}
                <div className="flex-1 overflow-y-auto p-6 md:p-12 pt-0 custom-scrollbar">
                    <div className="max-w-6xl mx-auto">
                        
                        {/* Synthesis Action Bar */}
                        {mode === 'synthesis' && articles.length > 0 && (
                            <div className="sticky top-0 z-30 mb-8 py-2">
                                <div className="glass-panel p-4 rounded-xl flex items-center justify-between shadow-2xl animate-fade-in-up">
                                    <div className="flex items-center gap-4">
                                        <div className="bg-primary-900/50 p-2.5 rounded-lg text-primary-400 border border-primary-500/20">
                                            <span className="font-bold text-xl leading-none">{selectedArticleIds.size}</span>
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="text-slate-200 font-medium text-sm">Sources Selected</span>
                                            <span className="text-slate-500 text-xs">Select high-quality sources for best results</span>
                                        </div>
                                    </div>
                                    <button
                                        onClick={initiateSynthesis}
                                        disabled={selectedArticleIds.size === 0 || isSynthesizing}
                                        className="bg-primary-600 hover:bg-primary-500 text-white px-6 py-3 rounded-lg font-medium shadow-lg shadow-primary-500/25 transition-all flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                                    >
                                        {isSynthesizing ? (
                                            <>
                                                <Loader2 className="animate-spin" size={18} />
                                                <span>Synthesizing Report...</span>
                                            </>
                                        ) : (
                                            <>
                                                <Settings2 size={18} fill="currentColor" />
                                                <span>Configure & Generate</span>
                                            </>
                                        )}
                                    </button>
                                </div>
                            </div>
                        )}

                        {error && (
                            <div className="flex items-center gap-3 p-4 bg-red-900/20 border border-red-900/50 rounded-xl text-red-200 mb-8 animate-fade-in mx-auto max-w-2xl">
                                <AlertTriangle size={20} className="shrink-0" />
                                {error}
                            </div>
                        )}

                        {/* Loading Skeletons */}
                        {isLoading && (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {[1, 2, 3, 4, 5, 6].map(i => (
                                    <div key={i} className="h-72 bg-slate-900/50 rounded-xl border border-slate-800 animate-pulse-slow p-5 flex flex-col">
                                        <div className="flex justify-between mb-4">
                                             <div className="h-4 w-20 bg-slate-800 rounded"></div>
                                             <div className="h-4 w-4 bg-slate-800 rounded-full"></div>
                                        </div>
                                        <div className="h-6 w-3/4 bg-slate-800 rounded mb-4"></div>
                                        <div className="h-4 w-full bg-slate-800/50 rounded mb-2"></div>
                                        <div className="h-4 w-5/6 bg-slate-800/50 rounded mb-2"></div>
                                        <div className="h-4 w-4/6 bg-slate-800/50 rounded mb-auto"></div>
                                        <div className="mt-6 flex gap-2">
                                            <div className="h-6 w-20 bg-slate-800 rounded"></div>
                                            <div className="h-6 w-20 bg-slate-800 rounded"></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}

                        {/* Article Grid */}
                        {!isLoading && articles.length > 0 && (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-20">
                                {articles.map((article) => (
                                    <NewsCard 
                                        key={article.id} 
                                        article={article} 
                                        selectable={mode === 'synthesis'}
                                        selected={selectedArticleIds.has(article.id)}
                                        onSelect={() => toggleSelection(article.id)}
                                    />
                                ))}
                            </div>
                        )}

                        {!isLoading && articles.length === 0 && !error && (
                            <div className="text-center py-20 opacity-30">
                                <LayoutDashboard size={48} className="mx-auto mb-4" />
                                <p>Ready to search</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}

        {/* Report Viewer Overlay */}
        <ReportViewer 
            isOpen={!!report && report.isOpen}
            title={report?.title || ''}
            content={report?.content || ''}
            onClose={() => setReport(prev => prev ? {...prev, isOpen: false} : null)}
            onSave={saveCurrentReport}
            sources={articles.filter(a => selectedArticleIds.has(a.id)).length > 0 
                ? articles.filter(a => selectedArticleIds.has(a.id)) 
                : articles 
            }
        />

        {/* Synthesis Options Modal */}
        {isSynthesisModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                <div className="bg-slate-900 w-full max-w-lg rounded-2xl border border-slate-700 shadow-2xl p-6 relative">
                     <button 
                        onClick={() => setIsSynthesisModalOpen(false)} 
                        className="absolute right-4 top-4 text-slate-500 hover:text-white"
                    >
                        <X size={20} />
                    </button>
                    
                    <h3 className="text-xl font-bold mb-2 flex items-center gap-2 text-white">
                        <Settings2 className="text-indigo-400" />
                        Configure Report
                    </h3>
                    <p className="text-sm text-slate-400 mb-6">
                        Customize how the AI synthesizes your selected sources.
                    </p>
                    
                    <div className="space-y-5">
                         {/* Tone Selection */}
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Report Tone</label>
                            <div className="grid grid-cols-2 gap-2">
                                {['Professional', 'Academic', 'Casual', 'Executive'].map((t) => (
                                    <button
                                        key={t}
                                        onClick={() => setSynthesisOptions({...synthesisOptions, tone: t as any})}
                                        className={`px-3 py-2 rounded-lg text-sm border transition-all ${synthesisOptions.tone === t ? 'bg-indigo-900/40 border-indigo-500 text-indigo-300' : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-600'}`}
                                    >
                                        {t}
                                    </button>
                                ))}
                            </div>
                         </div>

                         {/* Format Selection */}
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Structure & Format</label>
                            <select 
                                value={synthesisOptions.format}
                                onChange={(e) => setSynthesisOptions({...synthesisOptions, format: e.target.value as any})}
                                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm"
                            >
                                <option value="General Overview">General Overview (Balanced)</option>
                                <option value="Key Points">Bullet Points & Key Takeaways</option>
                                <option value="Comparative Analysis">Comparative Analysis (Side-by-side)</option>
                            </select>
                         </div>
                         
                         {/* Length Selection */}
                         <div>
                             <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Approximate Length</label>
                             <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
                                 {['Short', 'Medium', 'Long'].map(l => (
                                     <button
                                        key={l}
                                        onClick={() => setSynthesisOptions({...synthesisOptions, length: l as any})}
                                        className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${synthesisOptions.length === l ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
                                     >
                                         {l}
                                     </button>
                                 ))}
                             </div>
                         </div>

                         {/* Custom Instructions */}
                         <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Additional Instructions</label>
                            <textarea 
                                value={synthesisOptions.additionalInstructions}
                                onChange={(e) => setSynthesisOptions({...synthesisOptions, additionalInstructions: e.target.value})}
                                placeholder="E.g., Focus on the economic impact, highlight specific dates, or avoid technical jargon..."
                                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm h-24 resize-none"
                            />
                         </div>

                         <button 
                            onClick={handleSynthesize}
                            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 mt-2 shadow-lg shadow-indigo-500/20"
                        >
                            <Sparkles size={18} />
                            Generate Report
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* API Key Modal */}
        {isKeyModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
                <div className="bg-slate-900 w-full max-w-md rounded-2xl border border-slate-700 shadow-2xl p-6 relative">
                    <button 
                        onClick={() => setIsKeyModalOpen(false)} 
                        className="absolute right-4 top-4 text-slate-500 hover:text-white"
                    >
                        <X size={20} />
                    </button>
                    
                    <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                        <Key className="text-primary-500" />
                        Configure API Key
                    </h3>
                    <p className="text-sm text-slate-400 mb-6">
                        Enter your personal Gemini API key to use this app outside of the sandbox environment. The key is stored locally in your browser.
                    </p>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-xs font-medium text-slate-500 uppercase mb-1">Gemini API Key</label>
                            <input 
                                type="password" 
                                value={apiKeyInput}
                                onChange={(e) => setApiKeyInput(e.target.value)}
                                placeholder="AIza..."
                                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-primary-500 focus:outline-none transition-all font-mono text-sm"
                            />
                        </div>
                        
                        <div className="flex gap-3 pt-2">
                            <button 
                                onClick={saveLocalKey}
                                className="flex-1 bg-primary-600 hover:bg-primary-500 text-white font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2"
                            >
                                <Check size={18} />
                                Save Key
                            </button>
                            <button 
                                onClick={() => {
                                    localStorage.removeItem('gemini_api_key');
                                    setApiKeyInput('');
                                    alert("Key removed from storage.");
                                }}
                                className="px-4 py-2.5 bg-slate-800 hover:bg-red-900/30 hover:text-red-400 text-slate-400 rounded-lg transition-colors text-sm font-medium"
                            >
                                Clear
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

      </main>
    </div>
  );
}