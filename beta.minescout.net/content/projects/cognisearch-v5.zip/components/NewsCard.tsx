
import React from 'react';
import { ExternalLink, ShieldCheck, ShieldAlert, CheckCircle, Circle, Globe } from 'lucide-react';
import { Article } from '../types';

interface NewsCardProps {
  article: Article;
  selectable?: boolean;
  selected?: boolean;
  onSelect?: () => void;
}

export const NewsCard: React.FC<NewsCardProps> = ({ article, selectable, selected, onSelect }) => {
  
  const getTrustColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const openArticle = (e: React.MouseEvent) => {
    e.stopPropagation(); 
    if (article.url && article.url.startsWith('http')) {
        window.open(article.url, '_blank', 'noopener,noreferrer');
    }
  };

  // Safe defaults
  const trustScore = article.trustScore || 70;
  const biasRating = article.biasRating || 'Unknown';
  const displaySummary = article.summary || "Click to read the full article from the source.";

  return (
    <div 
      onClick={selectable ? onSelect : undefined}
      className={`
        relative flex flex-col p-5 rounded-xl border transition-all duration-300 group h-full
        ${selectable ? 'cursor-pointer' : ''}
        ${selected 
          ? 'bg-primary-900/20 border-primary-500 shadow-[0_0_15px_rgba(59,130,246,0.3)]' 
          : 'bg-slate-900/50 border-slate-800 hover:border-slate-600 hover:bg-slate-800/50'}
      `}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-2">
           <div className="p-1.5 bg-slate-800 rounded-md">
             {article.url ? <img src={`https://www.google.com/s2/favicons?domain=${new URL(article.url).hostname}&sz=32`} alt="icon" className="w-4 h-4 opacity-70" onError={(e) => e.currentTarget.src=''} /> : <Globe size={16} className="text-slate-500"/>}
           </div>
           <span className="text-xs font-mono text-slate-400 uppercase tracking-wider truncate max-w-[150px]">
              {article.source}
           </span>
        </div>
        {selectable && (
            <div className={`transition-all ${selected ? 'text-primary-500 scale-110' : 'text-slate-600'}`}>
                {selected ? <CheckCircle size={24} fill="currentColor" className="text-primary-500 bg-slate-900 rounded-full" /> : <Circle size={24} />}
            </div>
        )}
      </div>

      <h3 className="text-lg font-bold text-slate-100 leading-snug mb-3 group-hover:text-primary-400 transition-colors line-clamp-2">
        {article.title}
      </h3>

      <p className="text-slate-300 text-sm mb-6 line-clamp-3 leading-relaxed flex-grow">
        {displaySummary}
      </p>

      <div className="pt-4 border-t border-slate-800/50 mt-auto">
        <div className="flex items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-1.5 bg-slate-950/50 px-2 py-1 rounded border border-slate-800" title="Trust Score">
                <ShieldCheck size={14} className={getTrustColor(trustScore)} />
                <span className={`text-xs font-semibold ${getTrustColor(trustScore)}`}>{trustScore}% Trust</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-950/50 px-2 py-1 rounded border border-slate-800" title="Bias Rating">
                <ShieldAlert size={14} className="text-slate-400"/>
                <span className="text-xs text-slate-400">{biasRating} Bias</span>
            </div>
        </div>

        <button 
            onClick={openArticle}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-primary-600 text-slate-200 hover:text-white rounded-lg transition-all text-sm font-medium group/btn"
        >
            <span>Read Full Source</span>
            <ExternalLink size={14} className="group-hover/btn:translate-x-0.5 transition-transform" />
        </button>
      </div>
    </div>
  );
};
