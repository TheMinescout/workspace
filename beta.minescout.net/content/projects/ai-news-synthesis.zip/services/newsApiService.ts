

import { AnalyzedArticle } from '../types';

// List of potential CORS proxies, ordered by preference/reliability.
// The app will try these proxies sequentially if a fetch fails due to network issues.
// Each entry specifies the base URL of the proxy and an optional `param` name.
// If `param` is specified, the target URL will be appended as `?${param}=${encodedUrl}`.
// If `param` is an empty string, the target URL will be directly appended and encoded.
const CORS_PROXIES_CONFIG = [
  { url: 'https://corsproxy.io/?', param: '' },
  { url: 'https://proxy.cors.sh/', param: '' },
  { url: 'https://thingproxy.freeboard.io/fetch/', param: '' },
  { url: 'https://api.allorigins.win/raw?url=', param: '' },
  { url: 'https://cors.bridged.cc/', param: '' },
  { url: 'https://yacdn.mrkandreev.ru/', param: '' },
  { url: 'https://api.codetabs.com/v1/proxy', param: 'url' }, // This proxy expects '?url=' explicitly
  { url: 'https://cors.eu.org/', param: '' },
];

// Searches for real articles using NewsAPI.org. A key is required.
export const searchArticles = async (query: string, numArticles: number, apiKey: string): Promise<AnalyzedArticle[]> => {
  if (!apiKey) {
    throw new Error("A NewsAPI key is required to use the Standard Search feature. Please set it in the application settings.");
  }

  console.log(`Searching NewsAPI for "${query}"...`);
  
  const newsApiBaseUrl = `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&pageSize=${numArticles}&sortBy=relevancy&apiKey=${apiKey}`;

  let lastError: Error | null = null;
  let attemptMessages: string[] = []; // To collect messages from all attempts

  for (let i = 0; i < CORS_PROXIES_CONFIG.length; i++) {
    const proxyConfig = CORS_PROXIES_CONFIG[i];
    const proxyBaseUrl = proxyConfig.url;
    let proxiedUrl: string;

    if (proxyConfig.param) {
        // For proxies that require a specific parameter, e.g., 'https://proxy.com?url=...'
        proxiedUrl = `${proxyBaseUrl}?${proxyConfig.param}=${encodeURIComponent(newsApiBaseUrl)}`;
    } else {
        // For proxies where the target URL is directly appended, e.g., 'https://proxy.com/?https://target.com'
        proxiedUrl = `${proxyBaseUrl}${encodeURIComponent(newsApiBaseUrl)}`;
    }
    
    try {
      console.log(`Attempting to fetch with proxy: ${proxyBaseUrl}`);
      const response = await fetch(proxiedUrl);
      
      if (!response.ok) {
        const errorText = await response.text();
        // Specific error handling for NewsAPI HTTP status codes
        if (response.status === 401) {
            throw new Error("NewsAPI key is invalid or missing. Please check your settings and ensure it's correct.");
        }
        if (response.status === 429) {
            throw new Error("NewsAPI rate limit exceeded. Please wait a moment and try again, or consider upgrading your NewsAPI plan.");
        }
        if (response.status === 403) {
            throw new Error("NewsAPI access forbidden. This might be due to restrictions on the API key or source. Please review NewsAPI terms.");
        }
        // Generic HTTP error from NewsAPI via proxy, truncate for display
        throw new Error(`NewsAPI Error (${response.status} via ${proxyBaseUrl}): ${errorText.substring(0, 200) || 'Failed to fetch articles.'}`);
      }
      
      const data = await response.json();
      
      if (data.status === 'error') {
         // NewsAPI itself returns an error status in its JSON response
         if (data.code === 'apiKeyInvalid' || data.code === 'apiKeyMissing') {
             throw new Error("NewsAPI key is invalid or missing. Please check your settings and ensure it's correct.");
         }
         if (data.code === 'rateLimited') {
             throw new Error("NewsAPI rate limit exceeded. Please wait a moment and try again, or consider upgrading your NewsAPI plan.");
         }
         if (data.code === 'maximumResultsReached') {
            // This isn't a hard error but good to inform user. App handles 0 articles.
            console.warn("NewsAPI: Maximum results reached for free plan.");
         }
         throw new Error(`NewsAPI Error: ${data.message || 'An unknown error occurred with NewsAPI.'}`);
      }

      return data.articles
        .map((article: any): AnalyzedArticle => ({
          id: article.url,
          title: article.title || 'No Title Provided',
          url: article.url,
          summary: article.description || 'No summary available.',
          isAiAnalyzed: false,
        }))
        .filter((article: AnalyzedArticle) => article.url && !article.url.includes('removed')); 

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.warn(`Attempt with proxy ${proxyBaseUrl} failed:`, errorMessage);
      attemptMessages.push(`Proxy ${proxyBaseUrl} failed: ${errorMessage}`);
      lastError = error instanceof Error ? error : new Error(errorMessage);
      
      // Determine if the error is a retryable network error (e.g., proxy down, CORS issue).
      // Or if it's a specific NewsAPI HTTP error, that means the proxy worked but the API itself failed, so we should not retry with another proxy.
      const isRetryableNetworkError = 
        (error instanceof TypeError && (errorMessage.includes("Failed to fetch") || errorMessage.includes("NetworkError"))) ||
        (error instanceof DOMException && error.name === "NetworkError");

      if (isRetryableNetworkError && (i < CORS_PROXIES_CONFIG.length - 1)) {
        console.log(`Retryable network error with current proxy, trying the next one...`);
        continue; 
      }
      
      // For all other errors (non-retryable network errors, API-specific HTTP errors, 
      // JSON parsing errors, or if all proxies have been exhausted), re-throw the error.
      throw lastError;
    }
  }

  // If we reach here, all proxies failed with a "Failed to fetch" type error after all retries.
  let errorMessage = "All attempts to fetch articles from NewsAPI using available CORS proxies failed.";
  errorMessage += " This is likely due to client-side network restrictions (e.g., firewall, VPN, browser extensions like ad-blockers) or public proxy services being temporarily unavailable or blocked. Please check your network connection, disable any restrictive browser extensions, or try again later.";
  if (attemptMessages.length > 0) {
      errorMessage += `\nDetailed errors from attempts:\n${attemptMessages.map(msg => `- ${msg}`).join('\n')}`;
  }
  throw new Error(errorMessage);
};