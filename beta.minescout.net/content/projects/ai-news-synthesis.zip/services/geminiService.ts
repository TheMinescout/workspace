


import { GoogleGenAI } from "@google/genai";
import { AnalyzedArticle, ArticleSource, Settings, Bias, SynthesizedReport } from '../types';

const getAiClient = (apiKey: string) => {
    if (!apiKey) {
        throw new Error("A Gemini API key is required to use AI features. Please set it in the application settings.");
    }
    return new GoogleGenAI({ apiKey });
};

/**
 * Handles errors from Gemini API calls, providing more specific and user-friendly messages.
 * @param error The raw error object caught from the Gemini API call.
 * @param functionName A string indicating where the error occurred (e.g., 'article analysis', 'report synthesis').
 * @returns A new Error object with a refined message.
 */
const handleGeminiApiError = (error: unknown, functionName: string): Error => {
    let errorMessage = `An unknown error occurred during Gemini API call for ${functionName}.`;
    if (error instanceof Error) {
        const errorString = error.message.toLowerCase();
        if (errorString.includes('api key not valid') || errorString.includes('api key invalid')) {
            errorMessage = "Invalid Gemini API Key. Please check your settings and ensure your key is correct and active.";
        } else if (errorString.includes('quota exceeded')) {
            errorMessage = "Gemini API quota exceeded. You've made too many requests. Please wait a moment and try again, or check your Google Cloud project's quota settings.";
        } else if (errorString.includes('blocked')) {
            errorMessage = "The Gemini API request was blocked, possibly due to safety concerns or content policy violations. Try rephrasing your query or using different articles.";
        } else if (errorString.includes('network error') || errorString.includes('failed to fetch')) {
             errorMessage = "Network error connecting to Gemini API. Please check your internet connection.";
        } else if (errorString.includes('internal server error')) {
            errorMessage = "Gemini API experienced an internal server error. Please try again shortly.";
        } else {
            // Generic error message, including original error details
            errorMessage = `Gemini API Error: ${error.message}`;
        }
    } else {
        errorMessage = `An unexpected error occurred during Gemini API call for ${functionName}. Details: ${String(error)}`;
    }
    return new Error(errorMessage);
};


export const analyzeArticle = async (apiKey: string, article: ArticleSource, topics: string[]): Promise<Omit<AnalyzedArticle, 'id' | 'isAiAnalyzed'>> => {
    const ai = getAiClient(apiKey);
    const prompt = `
    Analyze the content of the news article titled "${article.title}" found at the URL: ${article.url}

    You MUST perform a full analysis of its content and provide the following details:
    1.  **summary**: A concise, 2-3 sentence neutral summary of the article's main points.
    2.  **trustworthiness**: A score from 0 to 100 representing the credibility of the information.
    3.  **bias**: "Left", "Balanced", or "Right".
    4.  **topic**: The most relevant category from this list: ${topics.join(", ")}.

    CRITICAL INSTRUCTIONS:
    - If you cannot access the content at the URL for any reason, your response MUST be a JSON object with a single key "error" with a string value explaining the failure (e.g., "Content is behind a paywall.").
    - Your entire successful response MUST be ONLY a single raw JSON object string, inside a single JSON markdown code block (e.g., \`\`\`json { ... } \`\`\`).
    `;

    try {
        const result = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }], // Use search to help access content at the URL
            }
        });
        
        if (!result || !result.text) {
            throw new Error("Model response was empty or blocked. This may be due to content safety filters. Try rephrasing your query or using a different article.");
        }

        const textResponse = result.text.trim();
        const jsonMatch = textResponse.match(/```json\s*([\s\S]*?)\s*```/);
        const jsonString = jsonMatch ? jsonMatch[1] : textResponse;
        
        let data;
        try {
            data = JSON.parse(jsonString);
        } catch (parseError) {
            console.error("Failed to parse AI model's JSON response:", parseError, "Raw response:", jsonString);
            throw new Error("AI model returned an unparsable response. Please try again.");
        }
        

        if (data.error) {
            throw new Error(data.error);
        }

        return {
            title: article.title,
            url: article.url,
            summary: data.summary,
            trustworthiness: Math.round(Number(data.trustworthiness) || 0),
            bias: data.bias,
            topic: data.topic,
        };

    } catch (error) {
        console.error(`Error analyzing article ${article.url}:`, error);
        throw handleGeminiApiError(error, 'article analysis');
    }
};


export const synthesizeReport = async (apiKey: string, query: string, articles: AnalyzedArticle[], settings: Settings): Promise<SynthesizedReport> => {
    const ai = getAiClient(apiKey);
    try {
        // Include the summary in the prompt context.
        // This allows the model to have a fallback if it fails to crawl the URL itself during synthesis,
        // or if the 'fallback' summary from NewsAPI was passed through from the app logic.
        const articlesString = articles.map((a, i) => 
            `[Source ${i + 1}] ${a.title}\nURL: ${a.url}\nSummary/Context: ${a.summary}`
        ).join('\n\n');

        // Determine Report Complexity to select the appropriate model
        let isComplexTask = false;

        if (settings.useAdvancedPdfSettings) {
            // In advanced mode, a high detail level (6/10 or higher) triggers the complex model
            isComplexTask = settings.pdfDetailLevel >= 6;
        } else {
            // In basic mode, 'Detailed' density or 'Long'/'Comprehensive' length triggers the complex model
            isComplexTask = settings.pdfDensity === 'detailed' || 
                            settings.pdfLength === 'long' || 
                            settings.pdfLength === 'comprehensive';
        }

        // Use gemini-3-pro-preview for complex tasks (slower, smarter)
        // Use gemini-2.5-flash for basic tasks (faster, efficient)
        const selectedModel = isComplexTask ? "gemini-3-pro-preview" : "gemini-2.5-flash";

        console.log(`Synthesizing report using model: ${selectedModel} (Complex Task: ${isComplexTask})`);

        const reportSpecs = settings.useAdvancedPdfSettings
            ? `
            - Number of Paragraphs: The 'Analysis & Synthesis' section MUST contain exactly ${settings.pdfNumParagraphs} paragraphs.
            - Detail Level: The detail level MUST be a ${settings.pdfDetailLevel} out of 10. (A score of 1 is a brief summary. A score of 5 includes key arguments and evidence from sources. A score of 10 includes deep analysis, direct quotes, and nuanced comparisons of source perspectives).
            `
            : `
            - Document Length: ${settings.pdfLength}.
            - Information Density: ${settings.pdfDensity}.
            - Desired Bias Perspective for Synthesis: ${settings.pdfBias}.
            `;

        const prompt = `
        You are a research analyst. Your task is to generate a JSON object containing a comprehensive report. The report's primary and sole purpose is to provide a direct and thorough answer to the user's question: "${query}".

        **Primary Sources:**
        You MUST base your entire report on the content found at the following URLs. Use them as your sole sources of information. Provide APA-style in-text citations and a full reference list at the end.

        ${articlesString}

        **Report Specifications:**
${reportSpecs}

        **JSON Output Instructions:**
        Your output MUST be a single JSON object. The JSON object should have two keys: "title" and "reportMarkdown".

        1.  **title**: Create a creative and engaging title for the report that directly relates to the user's query: "${query}".
        2.  **reportMarkdown**: Write the full report in well-formatted Markdown. The entire structure of the report should be organized to answer the user's question. For example, if the question is "What are the pros and cons of X?", the body MUST have sections for "Pros" and "Cons". Include the following sections using markdown headers (e.g., '## Executive Summary'):
            - Executive Summary: A brief overview of the key findings that directly answer the question.
            - Introduction: Background on the topic of "${query}".
            - Analysis & Synthesis: Synthesize information from the sources to construct a detailed answer to "${query}". Organize by theme (e.g., pros, cons, different perspectives). Analyze where sources agree and disagree. Use APA in-text citations, for example: (Author, Year).
            - Conclusion: A balanced summary of the synthesized information that directly answers the user's question.
            - References: A list of all sources formatted in proper APA style. The URLs in the references must be complete and correct.
        
        **CRITICAL:** The report specifications, especially the paragraph count and detail level if specified, are not suggestions. You MUST adhere to them strictly. Your entire response must be ONLY the raw JSON object string, enclosed in a single JSON markdown code block (e.g. \`\`\`json ... \`\`\`). Do not include any other text or explanations before or after the code block.
        `;

        const result = await ai.models.generateContent({
            model: selectedModel,
            contents: prompt,
            config: {
              tools: [{googleSearch: {}}],
            }
        });

        if (!result || !result.text) {
            console.error("Model response was empty or blocked during report synthesis.", result);
            throw new Error("The AI model returned an empty or invalid response while generating the report. This may be due to content safety filters. Please try again with different articles.");
        }

        const textResponse = result.text.trim();
        // Extract JSON from markdown code block if present, otherwise assume the whole response is the JSON string.
        const jsonMatch = textResponse.match(/```json\s*([\s\S]*?)\s*```/);
        const jsonString = jsonMatch ? jsonMatch[1] : textResponse;
        
        let reportJson;
        try {
            reportJson = JSON.parse(jsonString);
        } catch (parseError) {
            console.error("Failed to parse AI model's JSON report response:", parseError, "Raw response:", jsonString);
            throw new Error("AI model returned an unparsable report. Please try again.");
        }
        

        return {
            title: reportJson.title,
            content: reportJson.reportMarkdown,
        };
    } catch (error) {
        console.error("Error synthesizing report:", error);
        throw handleGeminiApiError(error, 'report synthesis');
    }
};
