
import { Settings } from './types';

export const TOPIC_AREAS = [
  "Politics & Policy",
  "Economics & Finance",
  "Ethics & Morality",
  "Technology & Innovation",
  "Environment & Climate",
  "Health & Safety",
  "Security & Privacy",
  "Society & Culture",
  "Science & Research",
  "Infrastructure & Logistics",
];

export const MAX_ARTICLES_TO_FETCH = 20;

export const DEFAULT_SETTINGS: Settings = {
  mode: 'ai',
  theme: 'system',
  searchBarPosition: 'bottom',
  minTrust: 50,
  biasPreference: 'any',
  numArticles: 10,
  selectedTopics: [...TOPIC_AREAS],
  // Basic PDF settings
  pdfLength: 'medium',
  pdfDensity: 'standard',
  pdfBias: 'balanced',
  // Advanced PDF settings
  useAdvancedPdfSettings: false,
  pdfNumParagraphs: 15,
  pdfDetailLevel: 5,
  pdfFontSize: 12,
  pdfFontType: 'Helvetica',
  minArticlesForReport: 4,
};

export const API_KEY_HELP_CONTENT = `
## How to Get a Google Gemini API Key

To use the AI Synthesis features, you need a free API key from Google AI Studio.

1.  **Go to Google AI Studio:**
    Open your web browser and navigate to [aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey). You will need to sign in with your Google account.

2.  **Create a New API Key:**
    Click the "Create API key" button. You might be asked to create a new project first if you don't have one.

3.  **Copy Your Key:**
    Your new API key will be generated and displayed. It's a long string of letters and numbers. Click the copy icon next to the key.

4.  **Paste the Key in This App:**
    Come back to this application, open the API key settings, and paste the key into the "Gemini API Key" field.

**Important:** Keep your API key secure and do not share it publicly.
`;