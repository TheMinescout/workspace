import { AnalyzedArticle, Settings } from "../types";

declare global {
  interface Window {
    jspdf: any;
  }
}

export const generatePdf = (reportTitle: string, reportContent: string, selectedArticles: AnalyzedArticle[], settings: Settings) => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({
    orientation: 'p',
    unit: 'mm',
    format: 'a4'
  });

  const margin = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const usableWidth = pageWidth - 2 * margin;

  // Font settings from user
  const useAdvanced = settings.useAdvancedPdfSettings;
  const baseFontSize = useAdvanced ? settings.pdfFontSize : 12;
  const fontMap = {
    'Helvetica': 'helvetica',
    'Arial': 'helvetica', // Arial is a common sans-serif, maps to jsPDF's default
    'Times New Roman': 'times',
    'Courier': 'courier'
  };
  const font = useAdvanced ? fontMap[settings.pdfFontType] : 'helvetica';

  let y = margin;

  const addPageIfNeeded = (spaceNeeded: number) => {
    if (y + spaceNeeded > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
  };

  // Title
  doc.setFontSize(baseFontSize + 8);
  doc.setFont(font, 'bold');
  const titleLines = doc.splitTextToSize(reportTitle, usableWidth);
  addPageIfNeeded(titleLines.length * (baseFontSize * 0.5));
  doc.text(titleLines, pageWidth / 2, y, { align: 'center' });
  y += titleLines.length * (baseFontSize * 0.5) + 5;

  // Generation Date
  doc.setFontSize(baseFontSize - 2);
  doc.setFont(font, 'italic');
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, pageWidth / 2, y, { align: 'center' });
  y += 10;
  
  doc.setFontSize(baseFontSize);
  doc.setFont(font, 'normal');

  const lines = reportContent.split('\n');
  const lineSpacing = baseFontSize * 0.35;

  lines.forEach(line => {
    addPageIfNeeded(baseFontSize * 0.5); // conservative estimate

    if (line.startsWith('## ')) {
        y += 2; // Extra space before header
        doc.setFont(font, 'bold');
        doc.setFontSize(baseFontSize + 4);
        const text = line.substring(3);
        const textLines = doc.splitTextToSize(text, usableWidth);
        addPageIfNeeded(textLines.length * (baseFontSize * 0.4) + 6);
        doc.text(textLines, margin, y);
        y += textLines.length * (baseFontSize * 0.4) + 4;
        doc.setFont(font, 'normal');
        doc.setFontSize(baseFontSize);
    } else if (line.startsWith('* ')) {
        const text = line.substring(2);
        const textLines = doc.splitTextToSize(text, usableWidth - 5);
        addPageIfNeeded(textLines.length * lineSpacing);
        doc.text('•', margin, y);
        doc.text(textLines, margin + 5, y);
        y += textLines.length * lineSpacing;
    } else if (line.match(/^\d+\.\s/)) {
        const bullet = line.match(/^\d+\./)![0];
        const text = line.replace(/^\d+\.\s/, '');
        const textLines = doc.splitTextToSize(text, usableWidth - 8);
         addPageIfNeeded(textLines.length * lineSpacing);
        doc.text(bullet, margin, y);
        doc.text(textLines, margin + 8, y);
        y += textLines.length * lineSpacing;
    } else if (line.trim() === '') {
        y += 5;
    } else {
        const textLines = doc.splitTextToSize(line, usableWidth);
        addPageIfNeeded(textLines.length * lineSpacing);
        doc.text(textLines, margin, y);
        y += textLines.length * lineSpacing;
    }
  });


  // Appendix for sources metadata
  doc.addPage();
  y = margin;
  doc.setFontSize(baseFontSize + 4);
  doc.setFont(font, 'bold');
  doc.text("Appendix: Source Metadata", margin, y);
  y += 10;

  doc.setFontSize(baseFontSize - 2);
  selectedArticles.forEach((article, index) => {
    const titleText = `Source ${index + 1}: ${article.title}`;
    const metaText = `Trustworthiness: ${article.trustworthiness}% | Bias: ${article.bias}`;
    
    const titleLines = doc.splitTextToSize(titleText, usableWidth);
    const metaLines = doc.splitTextToSize(metaText, usableWidth);

    addPageIfNeeded((titleLines.length + metaLines.length + 1) * (baseFontSize * 0.3) + 10);
    
    doc.setFont(font, 'bold');
    doc.text(titleLines, margin, y);
    y += titleLines.length * (baseFontSize * 0.3) + 2;

    doc.setFont(font, 'normal');
    doc.text('URL: ', margin, y);
    const urlXOffset = doc.getStringUnitWidth('URL: ') * doc.getFontSize() / doc.internal.scaleFactor;
    doc.setTextColor(6, 69, 173); // A nice blue for links
    doc.textWithLink(article.url, margin + urlXOffset, y, { url: article.url });
    doc.setTextColor(0, 0, 0); // Reset color
    y += (baseFontSize * 0.35);

    doc.text(metaLines, margin, y);
    y += metaLines.length * (baseFontSize * 0.3) + 5;
  });


  doc.save(`AI_Synthesis_Report.pdf`);
};

const markdownToHtml = (markdown: string): string => {
    const lines = markdown.split('\n');
    let html = '';
    let inList = false;

    for (const line of lines) {
        if (line.startsWith('## ')) {
            if (inList) { html += '</ul>\n'; inList = false; }
            html += `<h2>${line.substring(3)}</h2>\n`;
            continue;
        }
        if (line.startsWith('* ')) {
            if (!inList) { html += '<ul>\n'; inList = true; }
            html += `<li>${line.substring(2)}</li>\n`;
            continue;
        }

        if (inList) { html += '</ul>\n'; inList = false; }
        
        if (line.trim() === '') {
            html += '<br>\n';
        } else {
            // Escape basic HTML characters to prevent injection, then apply formatting
            let processedLine = line.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            processedLine = processedLine
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/(https?:\/\/[^\s,)]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
            html += `<p>${processedLine}</p>\n`;
        }
    }
    if (inList) { html += '</ul>\n'; } // Close list if file ends with it
    return html;
};

export const generateHtmlForReport = (reportTitle: string, reportContent: string, selectedArticles: AnalyzedArticle[]): string => {
    const reportHtml = markdownToHtml(reportContent);

    const sourcesHtml = selectedArticles
        .map((article, index) => {
            const title = article.title.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return `
            <div class="source">
                <h4>Source ${index + 1}: ${title}</h4>
                <p><strong>URL:</strong> <a href="${article.url}" target="_blank" rel="noopener noreferrer">${article.url}</a></p>
                <p><strong>Trustworthiness:</strong> ${article.trustworthiness}% | <strong>Bias:</strong> ${article.bias}</p>
            </div>
        `}).join('');
        
    const title = reportTitle.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Report: ${title}</title>
        <style>
            :root {
                --bg-color: #ffffff;
                --text-color: #111827;
                --link-color: #5a8a5a;
                --border-color: #e5e7eb;
                --header-color: #1f2937;
                --source-bg: #f9fafb;
            }
            @media (prefers-color-scheme: dark) {
                :root {
                    --bg-color: #1f2937;
                    --text-color: #d1d5db;
                    --link-color: #a3c2a3;
                    --border-color: #4b5563;
                    --header-color: #f9fafb;
                    --source-bg: #374151;
                }
            }
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
                line-height: 1.6;
                margin: 0;
                padding: 2rem;
                background-color: var(--bg-color);
                color: var(--text-color);
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
            }
            h1, h2, h3, h4 {
                color: var(--header-color);
                line-height: 1.2;
            }
            h1 { font-size: 2.2rem; margin-bottom: 0.5rem; text-align: center; }
            h2 { font-size: 1.5rem; margin-top: 2.5rem; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; }
            p { margin-bottom: 1rem; }
            ul { padding-left: 20px; }
            li { margin-bottom: 0.5rem; }
            a { color: var(--link-color); text-decoration: none; }
            a:hover { text-decoration: underline; }
            .meta {
                text-align: center;
                margin-bottom: 3rem;
                color: #6b7280;
                font-style: italic;
            }
            .source {
                margin-bottom: 1rem;
                padding: 1rem;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                background-color: var(--source-bg);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>${title}</h1>
            <div class="meta">Generated on: ${new Date().toLocaleDateString()}</div>
            
            <div class="report-content">
                ${reportHtml}
            </div>

            <div class="appendix">
                <h2>Appendix: Source Metadata</h2>
                ${sourcesHtml}
            </div>
        </div>
    </body>
    </html>
    `;
    return html;
};