
import React from 'react';
import Button from './Button';

interface HelpModalProps {
  isOpen: boolean;
  title: string;
  content: string;
  onClose: () => void;
}

const SimpleMarkdownRenderer: React.FC<{ content: string }> = ({ content }) => {
  const renderLine = (line: string, index: number) => {
    if (line.startsWith('## ')) {
      return <h2 key={index} className="font-bold text-xl my-4 pt-2 border-t border-gray-200 dark:border-gray-600">{line.substring(3)}</h2>;
    }
    if (line.startsWith('1. ') || line.startsWith('2. ') || line.startsWith('3. ') || line.startsWith('4. ')) {
       return <li key={index} className="list-decimal ml-6 mb-2">{line.substring(3)}</li>
    }
    if (line.trim() === '') {
      return <div key={index} className="h-4"></div>;
    }

    const parts = line.split(/(\[.*?\]\(.*?\))/g).filter(part => part);
    return (
      <p key={index} className="mb-2">
        {parts.map((part, i) => {
          if (part.startsWith('[') && part.includes('](') && part.endsWith(')')) {
            const textMatch = part.match(/\[(.*?)\]/);
            const urlMatch = part.match(/\((.*?)\)/);
            if (textMatch && urlMatch) {
              return <a href={urlMatch[1]} target="_blank" rel="noopener noreferrer" className="text-primary-600 dark:text-primary-400 hover:underline" key={i}>{textMatch[1]}</a>;
            }
          }
           if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i}>{part.slice(2, -2)}</strong>;
          }
          return <span key={i}>{part}</span>;
        })}
      </p>
    );
  };
  
  return (
    <div className="prose prose-sm sm:prose lg:prose-lg dark:prose-invert max-w-none">
      {content.split('\n').map(renderLine)}
    </div>
  );
};


const HelpModal: React.FC<HelpModalProps> = ({ isOpen, title, content, onClose }) => {
    if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl max-w-2xl w-full h-[80vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <h2 className="text-xl font-bold">{title}</h2>
          <Button onClick={onClose} aria-label="Close help" className="p-2 text-gray-500 dark:text-gray-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
           </Button>
        </div>
        <div className="p-6 overflow-y-auto flex-grow">
          <SimpleMarkdownRenderer content={content} />
        </div>
      </div>
    </div>
  );
};

export default HelpModal;
