import React from 'react';
import Spinner from './Spinner';

interface StatusIndicatorProps {
  message: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ message }) => {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center" role="alert" aria-live="assertive">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-xl flex flex-col items-center space-y-4 text-center max-w-sm">
        <Spinner className="w-10 h-10 text-primary-600" />
        <p className="text-lg font-medium text-gray-800 dark:text-gray-200">{message}</p>
      </div>
    </div>
  );
};

export default StatusIndicator;
