import React from 'react';
import { AnalyzedArticle } from '../types';
import ArticleCard from './ArticleCard';

interface ResultsGridProps {
  articles: AnalyzedArticle[];
  selectedArticleIds: Set<string>;
  onToggleSelect: (articleId: string) => void;
  onToggleSelectAll: () => void;
  allFilteredSelected: boolean;
}

const ResultsGrid: React.FC<ResultsGridProps> = ({ articles, selectedArticleIds, onToggleSelect, onToggleSelectAll, allFilteredSelected }) => {
  if (articles.length === 0) {
    return (
      <div className="text-center py-16">
        <h2 className="text-2xl font-semibold">No articles to display.</h2>
        <p className="text-gray-500 dark:text-gray-400 mt-2">Try adjusting your filters in the settings panel or searching for a new topic.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-end mb-4">
        <button
          onClick={onToggleSelectAll}
          className="px-4 py-2 text-sm font-semibold rounded-md border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-gray-900"
        >
          {allFilteredSelected ? 'Deselect All Visible' : 'Select All Visible'}
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map(article => (
          <ArticleCard
            key={article.id}
            article={article}
            isSelected={selectedArticleIds.has(article.id)}
            onToggleSelect={onToggleSelect}
          />
        ))}
      </div>
    </div>
  );
};

export default ResultsGrid;