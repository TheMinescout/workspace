
import React from 'react';
import { Settings, Theme, BiasPreference, PdfLength, PdfDensity, PdfBias, FontType, SearchBarPosition } from '../types';
import { TOPIC_AREAS, MAX_ARTICLES_TO_FETCH } from '../constants';
import Button from './Button'; // Import the new Button component

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  setSettings: React.Dispatch<React.SetStateAction<Settings>>;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ isOpen, onClose, settings, setSettings }) => {
  const handleSettingChange = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleMinArticlesChange = (newMin: number) => {
    setSettings(prev => ({
        ...prev,
        minArticlesForReport: newMin,
        numArticles: Math.max(prev.numArticles, newMin)
    }));
  };
  
  const handleTopicChange = (topic: string) => {
    const newTopics = settings.selectedTopics.includes(topic)
      ? settings.selectedTopics.filter(t => t !== topic)
      : [...settings.selectedTopics, topic];
    handleSettingChange('selectedTopics', newTopics);
  };
  
  return (
    <div className={`fixed inset-0 z-50 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/50" aria-hidden="true" onClick={onClose}></div>
      <div className={`absolute inset-y-0 right-0 max-w-sm w-full bg-white dark:bg-gray-800 shadow-xl flex flex-col transform transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="text-lg font-semibold">Settings</h2>
          <Button onClick={onClose} aria-label="Close settings panel" className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-2xl leading-none">&times;</Button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            {/* Filter Options */}
            <div className="space-y-4">
                <h3 className="font-semibold text-gray-800 dark:text-gray-200">Filter Options</h3>
                
                {settings.mode === 'ai' && (
                  <>
                    <div>
                        <label htmlFor="minTrust" className="block text-sm font-medium">Minimum Trust Score: <span className="font-bold">{settings.minTrust}%</span></label>
                        <input type="range" id="minTrust" min="0" max="100" value={settings.minTrust} onChange={e => handleSettingChange('minTrust', +e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                    </div>
                    <div>
                        <label htmlFor="biasPreference" className="block text-sm font-medium">Bias Preference</label>
                        <select id="biasPreference" value={settings.biasPreference} onChange={e => handleSettingChange('biasPreference', e.target.value as BiasPreference)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 dark:border-gray-600">
                            <option value="any">Any (show all)</option>
                            <option value="left">Left-leaning only</option>
                            <option value="balanced">Balanced/Neutral only</option>
                            <option value="right">Right-leaning only</option>
                            <option value="both">Both Left & Right</option>
                        </select>
                    </div>
                  </>
                )}

                <div>
                    <label htmlFor="numArticles" className="block text-sm font-medium">Number of Articles to Find: <span className="font-bold">{settings.numArticles}</span></label>
                    <input type="range" id="numArticles" min={settings.minArticlesForReport} max={MAX_ARTICLES_TO_FETCH} value={settings.numArticles} onChange={e => handleSettingChange('numArticles', +e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                </div>
            </div>

            {/* Topic Selection */}
            {settings.mode === 'ai' && (
              <div className="space-y-4">
                  <h3 className="font-semibold text-gray-800 dark:text-gray-200">Topic Selection</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                      {TOPIC_AREAS.map(topic => (
                          <label key={topic} className="flex items-center space-x-2 p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700">
                              <input type="checkbox" checked={settings.selectedTopics.includes(topic)} onChange={() => handleTopicChange(topic)} className="rounded text-primary-600 focus:ring-primary-500" />
                              <span>{topic}</span>
                          </label>
                      ))}
                      <label key="Other" className="flex items-center space-x-2 p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700">
                          <input type="checkbox" checked={settings.selectedTopics.includes("Other")} onChange={() => handleTopicChange("Other")} className="rounded text-primary-600 focus:ring-primary-500" />
                          <span>Other</span>
                      </label>
                  </div>
              </div>
            )}

            {/* PDF Output Settings */}
            {settings.mode === 'ai' && (
              <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                      <h3 className="font-semibold text-gray-800 dark:text-gray-200">PDF Output Settings</h3>
                      <label htmlFor="advanced-pdf-toggle" className="flex items-center cursor-pointer">
                          <span className="mr-3 text-sm font-medium">Advanced</span>
                          <div className="relative">
                              <input
                                  id="advanced-pdf-toggle"
                                  type="checkbox"
                                  className="sr-only peer"
                                  checked={settings.useAdvancedPdfSettings}
                                  onChange={e => handleSettingChange('useAdvancedPdfSettings', e.target.checked)}
                              />
                              <div className="w-11 h-6 bg-gray-200 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                          </div>
                      </label>
                  </div>

                  {settings.useAdvancedPdfSettings ? (
                      <div className="space-y-4 pt-2">
                          <div>
                              <label htmlFor="minArticlesForReport" className="block text-sm font-medium">Min. Articles for Report: <span className="font-bold">{settings.minArticlesForReport}</span></label>
                              <input type="range" id="minArticlesForReport" min="1" max={MAX_ARTICLES_TO_FETCH} value={settings.minArticlesForReport} onChange={e => handleMinArticlesChange(+e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                          </div>
                          <div>
                              <label htmlFor="pdfNumParagraphs" className="block text-sm font-medium">Paragraphs: <span className="font-bold">{settings.pdfNumParagraphs}</span></label>
                              <input type="range" id="pdfNumParagraphs" min="5" max="50" value={settings.pdfNumParagraphs} onChange={e => handleSettingChange('pdfNumParagraphs', +e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                          </div>
                          <div>
                              <label htmlFor="pdfDetailLevel" className="block text-sm font-medium">Detail Level: <span className="font-bold">{settings.pdfDetailLevel}/10</span></label>
                              <input type="range" id="pdfDetailLevel" min="1" max="10" value={settings.pdfDetailLevel} onChange={e => handleSettingChange('pdfDetailLevel', +e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                          </div>
                           <div>
                              <label htmlFor="pdfFontSize" className="block text-sm font-medium">Font Size: <span className="font-bold">{settings.pdfFontSize}pt</span></label>
                              <input type="range" id="pdfFontSize" min="8" max="16" value={settings.pdfFontSize} onChange={e => handleSettingChange('pdfFontSize', +e.target.value)} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-primary-600" />
                          </div>
                          <div>
                              <label htmlFor="pdfFontType" className="block text-sm font-medium">Font Type</label>
                              <select id="pdfFontType" value={settings.pdfFontType} onChange={e => handleSettingChange('pdfFontType', e.target.value as FontType)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 dark:border-gray-600">
                                  <option value="Helvetica">Helvetica (Sans-Serif)</option>
                                  <option value="Arial">Arial (Sans-Serif)</option>
                                  <option value="Times New Roman">Times New Roman (Serif)</option>
                                  <option value="Courier">Courier (Monospace)</option>
                              </select>
                          </div>
                      </div>
                  ) : (
                      <div className="space-y-4 pt-2">
                          <div>
                              <label htmlFor="pdfLength" className="block text-sm font-medium">Document Length</label>
                              <select id="pdfLength" value={settings.pdfLength} onChange={e => handleSettingChange('pdfLength', e.target.value as PdfLength)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 dark:border-gray-600">
                                  <option value="short">Short (1-2 pages)</option>
                                  <option value="medium">Medium (3-5 pages)</option>
                                  <option value="long">Long (6-10 pages)</option>
                                  <option value="comprehensive">Comprehensive (10+)</option>
                              </select>
                          </div>
                          <div>
                              <label htmlFor="pdfDensity" className="block text-sm font-medium">Information Density</label>
                              <select id="pdfDensity" value={settings.pdfDensity} onChange={e => handleSettingChange('pdfDensity', e.target.value as PdfDensity)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 dark:border-gray-600">
                                  <option value="summary">Summary (key points)</option>
                                  <option value="standard">Standard (balanced)</option>
                                  <option value="detailed">Detailed (in-depth)</option>
                              </select>
                          </div>
                          <div>
                              <label htmlFor="pdfBias" className="block text-sm font-medium">Bias Perspective</label>
                              <select id="pdfBias" value={settings.pdfBias} onChange={e => handleSettingChange('pdfBias', e.target.value as PdfBias)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 dark:border-gray-600">
                                  <option value="balanced">Balanced</option>
                                  <option value="left">Left-leaning</option>
                                  <option value="right">Right-leaning</option>
                              </select>
                          </div>
                      </div>
                  )}
              </div>
            )}
            
            {/* Appearance */}
            <div className="space-y-4">
                 <h3 className="font-semibold text-gray-800 dark:text-gray-200">Appearance</h3>
                 <div>
                    <label className="block text-sm font-medium">Theme</label>
                    <div className="mt-2 flex space-x-2">
                        {(['light', 'dark', 'system'] as Theme[]).map(theme => (
                            <button key={theme} onClick={() => handleSettingChange('theme', theme)} className={`px-3 py-1 rounded-md text-sm capitalize border-2 ${settings.theme === theme ? 'bg-primary-600 text-white border-primary-600' : 'bg-transparent border-gray-300 dark:border-gray-600'}`}>
                                {theme}
                            </button>
                        ))}
                    </div>
                 </div>
                 <div>
                    <label className="block text-sm font-medium">Search Bar Position</label>
                    <div className="mt-2 flex space-x-2">
                        <button 
                            onClick={() => handleSettingChange('searchBarPosition', 'top')} 
                            className={`px-3 py-1 rounded-md text-sm border-2 ${settings.searchBarPosition === 'top' ? 'bg-primary-600 text-white border-primary-600' : 'bg-transparent border-gray-300 dark:border-gray-600'}`}
                        >
                            Top (Header)
                        </button>
                        <button 
                            onClick={() => handleSettingChange('searchBarPosition', 'bottom')} 
                            className={`px-3 py-1 rounded-md text-sm border-2 ${settings.searchBarPosition === 'bottom' ? 'bg-primary-600 text-white border-primary-600' : 'bg-transparent border-gray-300 dark:border-gray-600'}`}
                        >
                            Bottom (Fixed)
                        </button>
                    </div>
                 </div>
            </div>

        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;