

import React, { useState, useEffect } from 'react';
import Button from './Button';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  geminiKey: string;
  newsApiKey: string;
  onSaveGeminiKey: (key: string) => void;
  onSaveNewsApiKey: (key: string) => void;
  onShowHelp: () => void;
}

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, geminiKey, newsApiKey, onSaveGeminiKey, onSaveNewsApiKey, onShowHelp }) => {
  const [gKey, setGKey] = useState(geminiKey);
  const [nKey, setNKey] = useState(newsApiKey);

  useEffect(() => {
    setGKey(geminiKey);
    setNKey(newsApiKey);
  }, [geminiKey, newsApiKey, isOpen]);

  const handleSave = () => {
    onSaveGeminiKey(gKey);
    onSaveNewsApiKey(nKey);
    onClose();
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="apiKeyModalTitle">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl max-w-md w-full">
        <div className="p-6">
          <h2 id="apiKeyModalTitle" className="text-xl font-bold mb-4">Set API Keys</h2>
          
          <div className="space-y-6">
            <div>
                <label htmlFor="gemini-key" className="text-sm font-bold text-gray-800 dark:text-gray-200 block mb-1">Gemini API Key</label>
                <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">
                    Required for "AI Synthesis" mode. This key enables deep analysis and report generation.
                </p>
                <input
                    id="gemini-key"
                    type="password"
                    value={gKey}
                    onChange={(e) => setGKey(e.target.value)}
                    placeholder="Enter your Gemini API key"
                    className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    aria-label="Gemini API Key Input"
                />
                 <Button onClick={onShowHelp} className="text-xs text-primary-600 dark:text-primary-400 hover:underline mt-1">
                    How do I get a key?
                 </Button>
            </div>

            <div>
                <label htmlFor="newsapi-key" className="text-sm font-bold text-gray-800 dark:text-gray-200 block mb-1">NewsAPI Key</label>
                 <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">
                    Required for real-time results in "Standard Search" mode. Get a free key from <a href="https://newsapi.org" target="_blank" rel="noopener noreferrer" className="underline">newsapi.org</a>.
                </p>
                 <input
                    id="newsapi-key"
                    type="password"
                    value={nKey}
                    onChange={(e) => setNKey(e.target.value)}
                    placeholder="Enter your NewsAPI.org key"
                    className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    aria-label="NewsAPI Key Input"
                />
            </div>
          </div>

        </div>
        <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-3 flex justify-end items-center space-x-3 rounded-b-lg">
          <Button onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-600 rounded-md border border-gray-300 dark:border-gray-500">
            Cancel
          </Button>
          <button 
            onClick={handleSave} 
            className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 disabled:bg-gray-400 dark:disabled:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-gray-800"
          >
            Save Keys
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyModal;
