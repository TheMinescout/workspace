import React from 'react';
import Button from './Button';

interface PdfViewerProps {
  reportTitle: string;
  reportContent: string;
  onClose: () => void;
  onDownload: () => void;
  onOpenInTab: () => void;
}

// A simple component to render markdown-like text
const SimpleMarkdownRenderer: React.FC<{ content: string }> = ({ content }) => {
  const renderLine = (line: string, index: number) => {
    if (line.startsWith('## ')) {
      return <h2 key={index} className="font-bold text-xl my-4 pt-2 border-t border-gray-200 dark:border-gray-600">{line.substring(3)}</h2>;
    }
     if (line.startsWith('* ')) {
        return <li key={index} className="ml-6 list-disc">{line.substring(2)}</li>
    }
    if (line.trim() === '') {
      return <div key={index} className="h-4"></div>; // Spacer for newlines
    }

    // Handle inline bold and italic
    const parts = line.split(/(\*\*.*?\*\*|\*.*?\*)/g).filter(part => part);
    return (
      <p key={index}>
        {parts.map((part, i) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i}>{part.slice(2, -2)}</strong>;
          }
          if (part.startsWith('*') && part.endsWith('*')) {
            return <em key={i}>{part.slice(1, -1)}</em>;
          }
          return <span key={i}>{part}</span>;
        })}
      </p>
    );
  };
  
  return (
    <div className="prose prose-sm sm:prose lg:prose-lg xl:prose-xl dark:prose-invert max-w-none">
      {content.split('\n').map(renderLine)}
    </div>
  );
};


const PdfViewer: React.FC<PdfViewerProps> = ({ reportTitle, reportContent, onClose, onDownload, onOpenInTab }) => {
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl max-w-4xl w-full h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <h2 className="text-xl font-bold truncate pr-4" title={reportTitle}>{reportTitle}</h2>
          <div className="flex items-center space-x-2">
             <button onClick={onOpenInTab} className="px-4 py-2 bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-100 rounded-md text-sm font-semibold hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors">
                Open in Tab
             </button>
             <button onClick={onDownload} className="px-4 py-2 bg-primary-600 text-white rounded-md text-sm font-semibold hover:bg-primary-700 transition-colors">
                Download PDF
             </button>
             <Button onClick={onClose} aria-label="Close report viewer" className="p-2 text-gray-500 dark:text-gray-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
             </Button>
          </div>
        </div>
        <div className="p-6 overflow-y-auto flex-grow">
          <SimpleMarkdownRenderer content={reportContent} />
        </div>
      </div>
    </div>
  );
};

export default PdfViewer;