
import React from 'react';
import { AppMode } from '../types';

interface GenerateButtonProps {
  selectedCount: number;
  onClick: () => void;
  minRequired: number;
  mode: AppMode;
}

const GenerateButton: React.FC<GenerateButtonProps> = ({ selectedCount, onClick, minRequired, mode }) => {
  const isEnabled = selectedCount >= minRequired;
  const articlesNeeded = minRequired - selectedCount;

  const buttonText = (() => {
    if (!isEnabled) {
      return `Select ${articlesNeeded} more ${articlesNeeded === 1 ? 'article' : 'articles'}`;
    }
    const actionText = mode === 'ai' ? 'Generate Report' : 'Compile Briefing';
    return `${actionText} (${selectedCount})`;
  })();
  
  const ariaLabel = isEnabled 
    ? `Generate content from ${selectedCount} selected articles`
    : `Select ${articlesNeeded} more articles to generate content`;


  return (
    <div className="fixed bottom-32 md:bottom-36 right-1/2 translate-x-1/2 z-30">
      <button
        onClick={onClick}
        disabled={!isEnabled}
        className="px-6 py-3 bg-primary-600 text-white font-semibold rounded-full shadow-lg hover:bg-primary-700 disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-gray-900"
        aria-label={ariaLabel}
      >
        {buttonText}
      </button>
    </div>
  );
};

export default GenerateButton;
