
import React from 'react';
import { AnalyzedArticle, Bias } from '../types';

interface ArticleCardProps {
  article: AnalyzedArticle;
  isSelected: boolean;
  onToggleSelect: (articleId: string) => void;
}

const getTrustBadgeStyle = (score: number): string => {
  if (score >= 75) return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
  if (score >= 40) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
  return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
};

const getBiasBadgeStyle = (bias: Bias): string => {
  switch (bias) {
    case 'Left': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
    case 'Balanced': return 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    case 'Right': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-300';
  }
};

const ArticleCard: React.FC<ArticleCardProps> = ({ article, isSelected, onToggleSelect }) => {
  let domain = 'Unknown Source';
  try {
      domain = new URL(article.url).hostname.replace('www.', '');
  } catch(e) {
      console.error(`Invalid URL for article ${article.title}: ${article.url}`);
  }
  const isError = article.summary.startsWith("AI analysis failed");


  return (
    <div className={`relative flex flex-col bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 border-2 ${isSelected ? 'border-primary-500 scale-[1.02]' : 'border-gray-200 dark:border-gray-700'}`}>
      <div className="absolute top-3 right-3 z-10">
          <input
              type="checkbox"
              checked={isSelected}
              onChange={() => onToggleSelect(article.id)}
              disabled={isError}
              className="h-6 w-6 rounded text-primary-600 focus:ring-primary-500 border-gray-300 dark:bg-gray-900 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={`Select article: ${article.title}`}
          />
      </div>
      <div className="p-5 flex-grow flex flex-col">
        <div className="mb-2">
            <span className="text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">{domain}</span>
        </div>
        <a href={article.url} target="_blank" rel="noopener noreferrer" className="block mb-2">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
            {article.title}
          </h3>
        </a>
        <div className="flex-grow mb-4">
            <p className="text-sm text-gray-600 dark:text-gray-300">
                {article.summary}
            </p>
        </div>
        {article.isAiAnalyzed && (
            <div className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700 flex flex-wrap gap-2 items-center text-xs">
                {article.trustworthiness !== undefined && (
                    <div 
                        className="cursor-help" 
                        title="AI-generated score based on analysis of the source's content and reputation. (0-100%)"
                    >
                        <span className={`px-2 py-1 font-semibold rounded-full ${getTrustBadgeStyle(article.trustworthiness)}`}>
                        Trust: {article.trustworthiness}%
                        </span>
                    </div>
                )}
                {article.bias && (
                    <div 
                        className="cursor-help" 
                        title="AI-generated political bias analysis based on language, topics, and source."
                    >
                        <span className={`px-2 py-1 font-semibold rounded-full ${getBiasBadgeStyle(article.bias)}`}>
                        {article.bias}
                        </span>
                    </div>
                )}
                {article.topic && (
                    <span className="px-2 py-1 font-semibold rounded-full bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300">
                        {article.topic}
                    </span>
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default ArticleCard;
