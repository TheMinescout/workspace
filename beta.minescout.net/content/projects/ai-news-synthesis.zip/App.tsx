
import React, { useState, useEffect, useMemo } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import { DEFAULT_SETTINGS, API_KEY_HELP_CONTENT } from './constants';
import { Settings, AnalyzedArticle, SynthesizedReport, AppMode, ArticleSource } from './types';
import * as geminiService from './services/geminiService';
import * as newsApiService from './services/newsApiService';
import { generatePdf, generateHtmlForReport } from './utils/pdfGenerator';

import Header from './components/Header';
import SearchBar from './components/SearchBar';
import SettingsPanel from './components/SettingsPanel';
import StatusIndicator from './components/StatusIndicator';
import ResultsGrid from './components/ResultsGrid';
import GenerateButton from './components/GenerateButton';
import PdfViewer from './components/PdfViewer';
import ApiKeyModal from './components/ApiKeyModal';
import HelpModal from './components/HelpModal';

const FAILED_ARTICLE_SUMMARY_PREFIX = "AI analysis failed";

const App: React.FC = () => {
  const [settings, setSettings] = useLocalStorage<Settings>('news-synthesis-settings', DEFAULT_SETTINGS);
  const [userApiKey, setUserApiKey] = useLocalStorage<string>('gemini-api-key', '');
  const [newsApiKey, setNewsApiKey] = useLocalStorage<string>('news-api-key', '');

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  const [searchHasBeenRun, setSearchHasBeenRun] = useState(false);
  const [loadingState, setLoadingState] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const [query, setQuery] = useState('');
  const [articles, setArticles] = useState<AnalyzedArticle[]>([]);
  const [selectedArticleIds, setSelectedArticleIds] = useState<Set<string>>(new Set());
  const [synthesizedReport, setSynthesizedReport] = useState<SynthesizedReport | null>(null);

  useEffect(() => {
    if (settings.theme === 'system') {
      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', systemPrefersDark);
    } else {
      document.documentElement.classList.toggle('dark', settings.theme === 'dark');
    }
  }, [settings.theme]);

  const handleSearch = async (newQuery: string) => {
    if (!newQuery.trim() || loadingState) return;

    if (!userApiKey) {
      setIsApiKeyModalOpen(true);
      return;
    }
    if (!newsApiKey) { // NewsAPI key is required for all searches now
      setIsApiKeyModalOpen(true);
      return;
    }

    setQuery(newQuery);
    setSearchHasBeenRun(true);
    setLoadingState('Searching for articles...');
    setError(null);
    setArticles([]);
    setSelectedArticleIds(new Set());
    setSynthesizedReport(null);
  
    try {
      const foundArticles = await newsApiService.searchArticles(newQuery, settings.numArticles, newsApiKey);

      if (foundArticles.length === 0) {
        throw new Error("No articles could be found. Please try a different query or topic.");
      }

      // Map directly to articles. We defer AI analysis until the Synthesis/Generation step.
      // This matches the "Standard Search" speed, but prepares for "AI" capability later.
      const processedArticles: AnalyzedArticle[] = foundArticles.map(article => ({
        ...article,
        isAiAnalyzed: false,
      }));
      
      setArticles(processedArticles);
      // Do not auto-select in search phase anymore, let user choose, or select all manually.

    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoadingState(null);
    }
  };

  const handleSynthesize = async () => {
    if (selectedArticleIds.size === 0) return;
    if (!userApiKey) {
        setIsApiKeyModalOpen(true);
        return;
    }

    setLoadingState('Preparing articles for analysis...');
    setError(null);

    const selectedArticles = articles.filter(a => selectedArticleIds.has(a.id));
    const articlesForReport: AnalyzedArticle[] = [];

    try {
      // If in AI mode, we perform the deep analysis NOW on the selected articles
      if (settings.mode === 'ai') {
        for (let i = 0; i < selectedArticles.length; i++) {
          const article = selectedArticles[i];
          
          // If already analyzed (e.g. from a previous run), skip re-analysis
          if (article.isAiAnalyzed) {
            articlesForReport.push(article);
            continue;
          }

          setLoadingState(`Analyzing content of source ${i + 1}/${selectedArticles.length}...`);
          
          try {
            const analysis = await geminiService.analyzeArticle(userApiKey, article, settings.selectedTopics);
            
            const updatedArticle: AnalyzedArticle = {
              ...article,
              ...analysis,
              id: article.id, // Keep original ID
              isAiAnalyzed: true
            };
            
            articlesForReport.push(updatedArticle);
            
            // Update state so the card shows the new badges/summary in the UI
            setArticles(prev => prev.map(a => a.id === article.id ? updatedArticle : a));

          } catch (analysisError) {
            console.warn(`Analysis failed for ${article.url}. Falling back to NewsAPI summary.`, analysisError);
            // Fallback: Use the original article (with NewsAPI summary)
            // This satisfies the requirement: "if it cant read it it will use the summary that is provided from news api"
            articlesForReport.push(article);
          }
        }
      } else {
        // Search mode - just use articles as is
        articlesForReport.push(...selectedArticles);
      }

      setLoadingState('Synthesizing comprehensive report...');
      const report = await geminiService.synthesizeReport(userApiKey, query, articlesForReport, settings);
      setSynthesizedReport(report);

    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoadingState(null);
    }
  };

  const handleCompileBriefing = () => {
      if (selectedArticleIds.size === 0) return;
      setLoadingState('Compiling briefing...');
      
      // For 'search' mode, we just create a simple compilation without AI synthesis
      const selectedArticles = articles.filter(a => selectedArticleIds.has(a.id));
      
      // Create a simple markdown report from the articles
      const simpleReportContent = `
## Executive Summary
This briefing contains ${selectedArticles.length} articles related to "${query}".

## Articles
${selectedArticles.map((a, i) => `
### ${i+1}. ${a.title}
*   **Source:** [Link](${a.url})
*   **Summary:** ${a.summary}
`).join('\n')}
      `;

      setSynthesizedReport({
          title: `Briefing: ${query}`,
          content: simpleReportContent.trim()
      });
      setLoadingState(null);
  };

  const toggleArticleSelection = (articleId: string) => {
    setSelectedArticleIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(articleId)) {
        newSet.delete(articleId);
      } else {
        newSet.add(articleId);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
      if (allFilteredSelected) {
          // Deselect all visible
          const newSet = new Set(selectedArticleIds);
          filteredArticles.forEach(a => newSet.delete(a.id));
          setSelectedArticleIds(newSet);
      } else {
          // Select all visible (that aren't failed)
          const newSet = new Set(selectedArticleIds);
          filteredArticles
            .filter(a => !a.summary.startsWith(FAILED_ARTICLE_SUMMARY_PREFIX))
            .forEach(a => newSet.add(a.id));
          setSelectedArticleIds(newSet);
      }
  };

  const filteredArticles = useMemo(() => {
    // Since analysis happens later, we allow unanalyzed articles to bypass filters initially.
    // If they have been analyzed (have a trustworthiness score), then we filter.
    
    if (settings.mode === 'search') return articles;

    return articles.filter(article => {
      // 1. Filter by Trust Score (only if analyzed)
      if (article.trustworthiness !== undefined && article.trustworthiness < settings.minTrust) {
        return false;
      }
      
      // 2. Filter by Bias (only if analyzed)
      if (settings.biasPreference !== 'any' && article.bias) {
        if (settings.biasPreference === 'left' && article.bias !== 'Left') return false;
        if (settings.biasPreference === 'right' && article.bias !== 'Right') return false;
        if (settings.biasPreference === 'balanced' && article.bias !== 'Balanced') return false;
        if (settings.biasPreference === 'both' && article.bias === 'Balanced') return false;
      }

      return true;
    });
  }, [articles, settings.mode, settings.minTrust, settings.biasPreference]);
  
  const allFilteredSelected = useMemo(() => {
      if (filteredArticles.length === 0) return false;
      return filteredArticles.every(a => selectedArticleIds.has(a.id));
  }, [filteredArticles, selectedArticleIds]);


  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300 font-sans text-gray-900 dark:text-gray-100 pt-16 pb-24">
      <Header 
        onToggleSettings={() => setIsSettingsOpen(!isSettingsOpen)} 
        mode={settings.mode}
        onModeChange={(mode) => setSettings(s => ({ ...s, mode }))}
        onSetApiKey={() => setIsApiKeyModalOpen(true)}
        searchBar={searchHasBeenRun && settings.searchBarPosition === 'top' ? (
            <SearchBar 
                onSearch={handleSearch} 
                isLoading={!!loadingState} 
                initialValue={query}
                variant="header"
            />
        ) : undefined}
      />

      <SettingsPanel 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        settings={settings} 
        setSettings={setSettings}
      />

      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        geminiKey={userApiKey}
        newsApiKey={newsApiKey}
        onSaveGeminiKey={setUserApiKey}
        onSaveNewsApiKey={setNewsApiKey}
        onShowHelp={() => setIsHelpModalOpen(true)}
      />

      <HelpModal
        isOpen={isHelpModalOpen}
        title="How to get a Gemini API Key"
        content={API_KEY_HELP_CONTENT}
        onClose={() => setIsHelpModalOpen(false)}
      />

      {loadingState && <StatusIndicator message={loadingState} />}

      <main className={`transition-all duration-500 ease-in-out flex flex-col items-center min-h-[calc(100vh-4rem)] px-4 sm:px-6 lg:px-8 ${!searchHasBeenRun ? 'justify-center' : 'pt-8'}`}>
        {!searchHasBeenRun && (
          <div className="text-center mb-12 max-w-2xl mx-auto">
             <h1 className="text-4xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-6xl mb-6">
               {settings.mode === 'ai' ? 'AI News Synthesis' : 'News Synthesis'}
             </h1>
             <div className="mb-8 flex justify-center">
               <div className="w-24 h-2 bg-gradient-to-r from-primary-600 to-green-400 rounded-full"></div>
             </div>
          </div>
        )}

        {!searchHasBeenRun && (
            <div className="w-full transition-all duration-500">
                <SearchBar 
                    onSearch={handleSearch} 
                    isLoading={!!loadingState} 
                    variant="centered"
                    initialValue={query}
                />
            </div>
        )}
        
        {error && (
          <div className="mt-8 w-full max-w-3xl bg-red-50 dark:bg-red-900/30 border-l-4 border-red-500 p-4 rounded-md shadow-sm animate-fade-in">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700 dark:text-red-200">{error}</p>
              </div>
            </div>
          </div>
        )}

        {articles.length > 0 && (
          <div className="w-full max-w-7xl mx-auto mt-8 animate-fade-in-up">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    {settings.mode === 'ai' ? 'Analysis Results' : 'Search Results'}
                </h2>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                    Showing {filteredArticles.length} of {articles.length} articles
                </div>
            </div>
            <ResultsGrid 
              articles={filteredArticles} 
              selectedArticleIds={selectedArticleIds}
              onToggleSelect={toggleArticleSelection}
              onToggleSelectAll={toggleSelectAll}
              allFilteredSelected={allFilteredSelected}
            />
          </div>
        )}
      </main>

      {searchHasBeenRun && settings.searchBarPosition === 'bottom' && (
          <div className="fixed bottom-6 left-0 right-0 z-30 px-4 flex justify-center animate-fade-in-up pointer-events-none">
             <div className="w-full max-w-2xl bg-white dark:bg-gray-800 rounded-full shadow-xl pointer-events-auto">
                <SearchBar 
                    onSearch={handleSearch} 
                    isLoading={!!loadingState} 
                    variant="centered"
                    initialValue={query}
                />
             </div>
          </div>
      )}

      <GenerateButton 
        selectedCount={selectedArticleIds.size} 
        onClick={settings.mode === 'ai' ? handleSynthesize : handleCompileBriefing}
        minRequired={settings.mode === 'ai' ? settings.minArticlesForReport : 1}
        mode={settings.mode}
      />

      {synthesizedReport && (
        <PdfViewer 
          reportTitle={synthesizedReport.title}
          reportContent={synthesizedReport.content}
          onClose={() => setSynthesizedReport(null)}
          onDownload={() => generatePdf(synthesizedReport.title, synthesizedReport.content, articles.filter(a => selectedArticleIds.has(a.id)), settings)}
          onOpenInTab={() => {
              const html = generateHtmlForReport(synthesizedReport.title, synthesizedReport.content, articles.filter(a => selectedArticleIds.has(a.id)));
              const blob = new Blob([html], { type: 'text/html' });
              const url = URL.createObjectURL(blob);
              window.open(url, '_blank');
          }}
        />
      )}
    </div>
  );
};

export default App;
