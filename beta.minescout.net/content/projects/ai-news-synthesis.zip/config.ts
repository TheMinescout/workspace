// This file is deprecated. The API key is managed via the `process.env.API_KEY` environment variable
// as configured in `vite.config.ts` and used in `services/geminiService.ts`.
// Do not add API keys to this file.
