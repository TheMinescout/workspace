
export enum Bias {
  Left = 'Left',
  Balanced = 'Balanced',
  Right = 'Right',
}

export interface ArticleSource {
  title: string;
  url: string;
}

export interface AnalyzedArticle extends ArticleSource {
  id: string;
  summary: string;
  trustworthiness?: number;
  bias?: Bias;
  topic?: string;
  isAiAnalyzed: boolean;
}

export interface SynthesizedReport {
  title: string;
  content: string; // Markdown content
}

export type AppMode = 'ai' | 'search';
export type Theme = 'light' | 'dark' | 'system';
export type SearchBarPosition = 'top' | 'bottom';

export type BiasPreference = 'any' | 'left' | 'balanced' | 'right' | 'both';

// Basic PDF Settings
export type PdfLength = 'short' | 'medium' | 'long' | 'comprehensive';
export type PdfDensity = 'summary' | 'standard' | 'detailed';
export type PdfBias = 'balanced' | 'left' | 'right' | 'custom';

// Advanced PDF Settings
export type FontType = 'Helvetica' | 'Arial' | 'Times New Roman' | 'Courier';


export interface Settings {
  mode: AppMode;
  theme: Theme;
  searchBarPosition: SearchBarPosition;
  minTrust: number;
  biasPreference: BiasPreference;
  numArticles: number;
  selectedTopics: string[];

  // Basic PDF settings
  pdfLength: PdfLength;
  pdfDensity: PdfDensity;
  pdfBias: PdfBias;

  // Advanced PDF settings toggle
  useAdvancedPdfSettings: boolean;

  // Advanced PDF settings values
  pdfNumParagraphs: number;
  pdfDetailLevel: number; // Scale of 1-10
  pdfFontSize: number; // In points (pt)
  pdfFontType: FontType;
  minArticlesForReport: number;
}